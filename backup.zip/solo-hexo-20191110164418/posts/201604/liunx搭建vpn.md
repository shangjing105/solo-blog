title: liunx搭建vpn
date: '2016-04-21 12:32:08'
updated: '2016-04-21 12:32:08'
tags: [Linux, vpn]
permalink: /articles/2016/04/21/1461213105621.html
---
<h2 id="22-安装pptp服务">安装PPTP服务</h2>
<p>运行如下命令</p>
<pre name="code" class="prettyprint"><code class="language-bash hljs  has-numbering">wget http://www.<span class="hljs-number">5</span>yun.org/Soft/linux/Openvz-vpn/openvps_vpn_centos-<span class="hljs-number">5</span>-<span class="hljs-number">6</span>.sh
chmod a+x openvps_vpn_centos-<span class="hljs-number">5</span>-<span class="hljs-number">6</span>.sh 
bash openvps_vpn_centos-<span class="hljs-number">5</span>-<span class="hljs-number">6</span>.sh

<span class="hljs-comment">#如果以上地址不可用，可尝试以下命令，</span>
<span class="hljs-comment">#这个脚本只提供三个选项，一般选择1就可以自动完成全部过程</span>
<span class="hljs-comment">#去掉注释符号</span>
<span class="hljs-comment">#wget http://www.hi-vps.com/shell/vpn_centos6.sh</span>
<span class="hljs-comment">#chmod a+x vpn_centos6.sh</span>
<span class="hljs-comment">#bash vpn_centos6.sh</span></code></pre>
<ul class="pre-numbering">
<li>1</li>
<li>2</li>
<li>3</li>
<li>4</li>
<li>5</li>
<li>6</li>
<li>7</li>
<li>8</li>
<li>9</li>
<li>10</li>
</ul>
<p>上边第一步是获取一个自动脚本，第二步是给它运行权限，第三步是运行。有时候会遇到第一步无法成功，这时候在本地先下载这个文件，再使用Putty或者SSH客户端上传到VPS也是可以的。&nbsp;<br />执行以上命令后将会返回一个选择系统版本的提示信息，因为之前我们选择的是centos6 ，因此选择第2项，输入2，回车：</p>
<pre name="code" class="prettyprint"><code class="language-bash hljs  has-numbering">please select your operation system
which <span class="hljs-keyword">do</span> you want to?input the number.
<span class="hljs-number">1</span>. my system is centos5 <span class="hljs-number">32</span>bit(only support <span class="hljs-number">32</span>bit)
<span class="hljs-number">2</span>. my system is centos6 <span class="hljs-number">32</span>bit or <span class="hljs-number">64</span>bit(they are support)
<span class="hljs-number">3</span>. repaire VPN service
<span class="hljs-number">4</span>. add VPN user</code></pre>
<ul class="pre-numbering">
<li>1</li>
<li>2</li>
<li>3</li>
<li>4</li>
<li>5</li>
<li>6</li>
</ul>
<p>执行命令后将自动安装，成功后返回一下信息：&nbsp;<br />VPN service is installed, your VPN username is vpn_name,VPN password is&nbsp;<strong><em>**</em></strong>&nbsp;<br />这句话提示成功创建了一个名为vpn_name的账户，密码为&nbsp;<strong>**</strong>。</p>
<p>执行命令后报404错误，或者提示文件或目录不存在，是因为没能成功下载安装包。&nbsp;<br />这里提供手动下载安装包的方法&nbsp;<br />如果是centos6，执行以下命令：</p>
<pre name="code" class="prettyprint"><code class="language-bash hljs  has-numbering">wget http://linux.dell.com/dkms/permalink/dkms-<span class="hljs-number">2.0</span>.<span class="hljs-number">17.5</span>-<span class="hljs-number">1</span>.noarch.rpm
wget https://acelnmp.googlecode.com/files/kernel_ppp_mppe-<span class="hljs-number">1.0</span>.<span class="hljs-number">2</span>-<span class="hljs-number">3</span>dkms.noarch.rpm
wget https://qiaodahai.googlecode.com/files/pptpd-<span class="hljs-number">1.3</span>.<span class="hljs-number">4</span>-<span class="hljs-number">2</span>.el6.i686.rpm
wget https://logdns.googlecode.com/files/ppp-<span class="hljs-number">2.4</span>.<span class="hljs-number">5</span>-<span class="hljs-number">17.0</span>.rhel6.i686.rpm</code></pre>
<ul class="pre-numbering">
<li>1</li>
<li>2</li>
<li>3</li>
<li>4</li>
</ul>
<p>如果是 centos5，则执行以下命令：</p>
<pre name="code" class="prettyprint"><code class="language-bash hljs  has-numbering">wget http://linux.dell.com/dkms/permalink/dkms-<span class="hljs-number">2.0</span>.<span class="hljs-number">17.5</span>-<span class="hljs-number">1</span>.noarch.rpm
wget https://acelnmp.googlecode.com/files/kernel_ppp_mppe-<span class="hljs-number">1.0</span>.<span class="hljs-number">2</span>-<span class="hljs-number">3</span>dkms.noarch.rpm
wget https://acelnmp.googlecode.com/files/pptpd-<span class="hljs-number">1.3</span>.<span class="hljs-number">4</span>-<span class="hljs-number">1</span>.rhel5.<span class="hljs-number">1</span>.i386.rpm
wget https://fastlnmp.googlecode.com/files/ppp-<span class="hljs-number">2.4</span>.<span class="hljs-number">4</span>-<span class="hljs-number">9.0</span>.rhel5.i386.rpm</code></pre>
<ul class="pre-numbering">
<li>1</li>
<li>2</li>
<li>3</li>
<li>4</li>
</ul>
<h1 id="3-添加自己的vpn账号"><a name="t5"></a>3. 添加自己的VPN账号</h1>
<p>如何添加自己的vpn账户名？ 比如我想用 anonymous 这个帐号，密码设置为 abc@123 (<strong>注意，危险！仅作为演示用，千万别设置这样的密码！</strong>)</p>
<p>执行下面这句代码来添加vpn账户：&nbsp;<br /><code>bash openvps_vpn_centos-5-6.sh</code>&nbsp;<br />返回的信息选项中，选择第4项：4.add VPN user&nbsp;<br />根据提示输入用户名，如 anonymous，再输入密码 即可完成vpn的架设了。&nbsp;<br />使用时，在本地新建VPN连接，地址和端口填写VPS的地址和端口，用户名密码填写自己设置的VPN的用户名和密码，然后连接，就可以了。&nbsp;<br />如有疑问，请留言讨论。</p>