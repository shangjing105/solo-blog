title: openfire服务的安装（二）
date: '2017-07-28 11:28:32'
updated: '2017-07-28 11:28:32'
tags: [java]
permalink: /articles/2018/05/16/1526527712478.html
---
![](https://img.hacpai.com/bing/20180107.jpg?imageView2/1/w/960/h/520/interlace/1/q/100)


# openfire服务的安装
1、首先下载OpenFire的Linux安装包openfire 4.1.5，下载地址http://www.igniterealtime.org/downloads/index.jsp#openfire。

你可以根据系统不同，选择不同的版本，如果是windows或mac可以直接安装openfire程序，安装完成后直接输入http://127.0.0.1:9090/setup/index.jsp即可进入设置页面

2、复制安装包到Linux服务器上/opt中

3、解压
``
tar -zxvf openfire_4_1_5.tar.gz 
``

4.启动Openfire
``
 ./openfire start 
``

5.浏览器下输入http://你的ip:9090/setup/index.jsp，进入配置页面

# 设置openfire

1.设置语言，选中文
![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-23c5d24a067581cc?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

2.主机设置
设置主机的访问ip地址
![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-02bc457192173906?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

3.数据库设置
如果要设置外部数据库（推荐，比如：MySQL），选择标准数据库连接
其中数据库名称[database-name]改为openfire—》自己创建名字为openfire的数据库
![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-d7e032872cc565db?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-f656509bc379e227?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

4.设置openfire服务器管理员的帐号和密码
其他步骤都可以选择默认,设置登陆账号，然后安装完成
![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-33b431bd4f401d0f?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

5. 登录后台查看管理控制台
![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-849184320aa01d89?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

# 安装Spark测试XMPP连接

下载spark 地址和上面一样：http://www.igniterealtime.org/downloads/index.jsp#openfire

**登录**

![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-1c0fa8edf6ad038d?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

**注册**

![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-25044300b1b79fd1?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

**主界面**

![这里写图片描述](http://upload-images.jianshu.io/upload_images/2728175-5ddb77ad93e7068f?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)

---
详细实现推送的代码，请看下一篇文章