title: 你想了解的水花一现APP
date: '2016-09-10 18:21:11'
updated: '2016-10-31 16:07:19'
tags: [java, ionic]
permalink: /articles/2016/09/10/1473502776082.html
---


# 1.关于水花一现APP的想法
作为一名有理想的程序员，在工作之外总会不断的学习，去尝试一些做一些有趣的东西。在我一次看到看到Ionic的开发介绍后，看到开发APP如此简单，不用单独去学习android和ios，可以做出自己想要的东西，我就慢慢萌发了这个APP的想法。


***下载地址在这里：***[https://www.pgyer.com/0qj6](https://www.pgyer.com/0qj6)

    暂时只有android版可以下载，ios版没有签名不可以安装。



# 2.一览效果图为先
![精选](http://o6n64wdk9.bkt.clouddn.com/0a56a7c12c8840338112e4b4a235aa76.png)

![精选详情](http://o6n64wdk9.bkt.clouddn.com/7192e09422934f9c840caa8ad57d7400.jpeg)

![美图](http://o6n64wdk9.bkt.clouddn.com/2bef26cb21ee4d1a8232051a66a9716c.png)

![美图详情](http://o6n64wdk9.bkt.clouddn.com/c411b56a965d45cd88f195a7c2c6be2d.jpeg)

![笑话](http://o6n64wdk9.bkt.clouddn.com/eff8df44661141cab2d960ecee194340.png)



# 3.如何实现自己的APP
首先你要是一名有理想的程序员，然后需要一些专业的技能来实现。

如果你是后端开发人员，会一门后端语言，你就可以给自己的APP开发接口和后台管理，包括设计好你想要的app。再找一个时间去学习一下ionic的开发，然后就可以去实现你的app啊!

但是你如果是一个前端开发，那就比较麻烦了，对于ionic想必前端应该比较简单吧，对于后台你如果会点简单的后端语言（如：PHP）也可以去实现以下，如果你是纯前端，你可能需要找个和你志同道合的伙伴，一起来实现。



# 4.最后
**我会在以后的文章中更新关于我这个APP开发过程中的一系列教程，如果有同样想法的，可以关注我的博客，也可以来信向我咨询，欢迎各位伙伴打扰！**


博客:[http://www.shuihua.me](http://www.shuihua.me)

微信公众号:***水花一现***，***shuihuayixian***

邮箱:***shangjing105@163.com***

Github:[https://github.com/shangjing105](https://github.com/shangjing105)

QQ:***787019494***