title: Linux安装java环境
date: '2016-04-15 14:22:19'
updated: '2016-04-15 14:22:19'
tags: [Linux, java]
permalink: /javaInstall
---
<p class="p1">&nbsp;</p>
<p class="p2"><span class="s2"><a href="http://mirrors.linuxeye.com/">http://mirrors.linuxeye.com/</a></span></p>
<p class="p3"><span class="s1">查看liunx版本 uname -a</span></p>
<p class="p1">&nbsp;</p>
<p class="p3"><span class="s1"><strong>1.根据不同版本下载32或64位的jdk</strong></span></p>
<p class="p3"><span class="s1">到usr文件夹下 新建 mkdir java</span></p>
<p class="p3"><span class="s1">&nbsp;wget http://mirrors.linuxeye.com/jdk/jdk-8u77-linux-x64.tar.gz</span></p>
<p class="p3"><span class="s1">解压</span></p>
<p class="p3"><span class="s1">&nbsp;tar xzf jdk-8u77-linux-x64.tar.gz&nbsp;</span></p>
<p class="p3"><span class="s1">移动到</span></p>
<p class="p3"><span class="s1">到usr文件夹下 新建 mkdir java</span></p>
<p class="p3"><span class="s1">mv jdk1.8.0_77 /usr/java/</span></p>
<p class="p1">&nbsp;</p>
<p class="p4"><span class="s1"><strong>2. 修改.bash_profile文件</strong>&nbsp;</span></p>
<p class="p3"><span class="s1">这种方法更为安全，它可以把使用这些环境变量的权限控制到用户级别，如果你需要给某个用户权限使用这些环境变量，你只需要修改其个人用户主目录下的.bash_profile文件就可以了。&nbsp;</span></p>
<p class="p3"><span class="s1">&middot;用文本编辑器打开用户目录下的.bash_profile文件&nbsp;</span></p>
<p class="p3"><span class="s1">&middot;在.bash_profile文件末尾加入：&nbsp;</span></p>
<p class="p1">&nbsp;</p>
<p class="p3"><span class="s1">export JAVA_HOME=/usr/share/jdk1.6.0_14&nbsp;</span></p>
<p class="p3"><span class="s1">export PATH=$JAVA_HOME/bin:$PATH&nbsp;</span></p>
<p class="p3"><span class="s1">export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar&nbsp;</span></p>
<p class="p1">&nbsp;</p>
<p class="p3"><span class="s1">&middot;重新登录 &nbsp;reboot</span></p>
<p class="p4"><span class="s1">java -version &nbsp;查看jdk版本</span></p>
<p class="p5">&nbsp;</p>
<p class="p4"><span class="s1"><strong>3.安装tomcat</strong></span></p>
<p class="p3"><span class="s1">wget&nbsp;http://mirrors.linuxeye.com/apache/tomcat/v8.0.32/apache-tomcat-8.0.32.tar.gz</span></p>
<p class="p3"><span class="s1">解压</span></p>
<p class="p3"><span class="s1">&nbsp;tar xzf apache-tomcat-8.0.32.tar.gz&nbsp;</span></p>
<p class="p1">&nbsp;</p>
<p class="p1">&nbsp;</p>
<p class="p3"><span class="s1"><strong>4.安装mysql</strong></span></p>
<p class="p2"><span class="s2"><a href="http://www.cnblogs.com/xiaoluo501395377/archive/2013/04/07/3003278.html">http://www.cnblogs.com/xiaoluo501395377/archive/2013/04/07/3003278.html</a></span></p>
<p class="p1">&nbsp;</p>
<p class="p1">&nbsp;</p>
<p class="p3"><span class="s1">创建用户并授权</span></p>
<p class="p3"><span class="s1">create user admin identified by 'admin&rsquo;;</span></p>
<p class="p3"><span class="s1">GRANT ALL PRIVILEGES ON *.* TO admin@'%&rsquo;;</span></p>
<p class="p1">&nbsp;</p>
<p class="p1">&nbsp;</p>
<p class="p1">&nbsp;</p>
<p class="p1">&nbsp;</p>