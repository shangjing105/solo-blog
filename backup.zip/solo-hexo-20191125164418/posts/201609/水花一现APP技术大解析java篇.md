title: 水花一现APP技术大解析-java篇
date: '2016-09-11 17:46:48'
updated: '2016-10-31 16:08:16'
tags: [spring, 水花, java]
permalink: /articles/2016/09/11/1473587191877.html
---
![远望](http://o6n64wdk9.bkt.clouddn.com/2e72209c3fa149c7b722fc1d1f755e36.png)


***下载地址在这里：***[https://www.pgyer.com/0qj6](https://www.pgyer.com/0qj6)


APP下载只可以安装android版的，至于iOS版的没有iOS签名是不能安装，我也是只给自己手机安装了一个ios版的，有android手机的可以下载试试。

	水花一现=java + mysql + ionic 不明白这些技术可以百度搜下关键字
	
# 1.java后端技术分析

	java后端=spring boot + spring data jpa + spring security + spring thymeleaf

## 1.1 spring boot
我使用的是java的微框架**spring boot**，用于简化spring应用的初始搭建以及开发过程。没有使用配置比较麻烦的**SSM**架构,因为想比于麻烦的SSM架构，spring boot架构可以简化很多配置和没有必要的开发。对于不熟悉spring boot的我建议看下：

<<[Spring Boot——2分钟构建spring web mvc REST风格HelloWorld](http://jinnianshilongnian.iteye.com/blog/1997192)>>

<<[深入学习微框架：Spring Boot](http://blog.csdn.net/zgmzyr/article/details/49837077)>>

 这些都是官网上的程序清单，看完后想必你对spring boot就应该有个了解。

**maven添加** 


	<parent>    
		<groupId>org.springframework.boot</groupId>  
    	<artifactId>spring-boot-starter-parent</artifactId>  
    	<version>1.4.0.RELEASE</version>  
    </parent>  
	<dependencies>
    	<dependency>
        	<groupId>org.springframework.boot</groupId>
        	<artifactId>spring-boot-starter-web</artifactId>
    	</dependency>
	</dependencies>



## 1.2 spring data jpa

在spring boot项目里使用的**spring data jpa**来简化对数据库的操作，不将时间消耗在重复的增删查改上。spring data jpa是比较简单**ORM**框架，对ORM技术（如：Hibernate,mybatis,spring data jpa）有过使用的人很快就能上手。

<<[使用 Spring Data JPA 简化 JPA 开发](http://www.ibm.com/developerworks/cn/opensource/os-cn-spring-jpa/)>>

**maven添加**


    <dependency>
        <groupId>org.springframework.data</groupId>
        <artifactId>spring-data-jpa</artifactId>
        <version>1.10.2.RELEASE</version>
    </dependency>


## 1.3 spring security
上面的两种技术主要是为了简化接口的开发速度，至于**spring security**是安全权限管理，是为了后台管理系统的管理权限认证的，这都是spring boot的集成技术，使用方便，不用自己去开发，现在都流行敏捷开发，使用这些可以加快开发速度。

<<[spring security技术使用](https://spring.io/guides/gs/securing-web/)>>

**maven添加**


		<dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>


## 1.4 spring thymeleaf
**spring thymeleaf**是前端模板引擎，类似于jsp,freemarker前端模板，是为了更好的渲染前端页面。我这里使用它是为了开发后台的管理界面，有后端开发经验的相比用一下应该也简单。

<< [spring-boot-web-ui及thymeleaf基本使用](http://jishiweili.iteye.com/blog/2095536)>>

**maven添加**


		<dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-thymeleaf</artifactId>
        </dependency>


这里放上几张后台管理的界面

![login](http://o6n64wdk9.bkt.clouddn.com/e96774dd60f946408e94a0b6d9eb7dbc.png)

![main](http://o6n64wdk9.bkt.clouddn.com/49cb6211751b4ba0b8669a1887dd88b7.png)

![123](http://o6n64wdk9.bkt.clouddn.com/7e14c34a2c814cf789c9198a38372840.png)

# 2.MySQL

	数据库使用mysql,这个没什么介绍的。主要是设计数据库的结构，完成数据存储。
    也可以使用其他数据库：oracle,mongodb等。

# 3.最后

	这篇先将后端使用技术介绍完成，后面几篇在介绍其他技术。

**感想：**上面使用的spring boot相关的技术我在以前也都没有使用过，也是为了做这个项目学习的。对于有java web方面的开发经验的伙伴应该也可以试试，看看官方文档就可以开始，比较简单。不过我在使用中也遇到过不少的坑，但这都是正常的，学习新技术不可能一点坑都没有，不过踏过这个坑就可以。欢迎各位关注我，大家一起进步

大家可以关注我的github账号，关于APP的代码我都放在了github上，有需要的可以下载下来试试。有问题了可以联系我

博客:[http://www.shuihua.me](http://www.shuihua.me)

微信公众号:***水花一现***，***shuihuayixian***

邮箱:***shangjing105@163.com***

Github:[https://github.com/shangjing105](https://github.com/shangjing105)

QQ:***787019494***