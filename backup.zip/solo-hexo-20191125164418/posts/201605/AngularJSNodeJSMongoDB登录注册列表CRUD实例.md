title: AngularJS，NodeJS，MongoDB 登录、注册 列表CRUD实例
date: '2016-05-05 18:43:25'
updated: '2016-05-05 18:43:25'
tags: [nodejs, mongodb, Gitblit, angularjs]
permalink: /articles/2016/05/05/1462445005857.html
---
<p>
	先上效果图
</p>
<p>
	<strong>首页</strong><strong></strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/dd96c96c7c434d89bc517b963dfb6cd4.jpg" width="440" height="224" alt="" /><br />
</strong>
</p>
<p>
	<strong>登录</strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/407318dca17d4876a189057cb5169157.jpg" width="696" height="407" alt="" /><br />
</strong>
</p>
<p>
	<strong>注册</strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/a22728d2aa0c44e48e6ff9888e900241.jpg" width="536" height="375" alt="" /><br />
</strong>
</p>
<p>
	<strong>列表展示</strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/a669ba2912c845d2a93fde5765f4d154.jpg" width="636" height="187" alt="" /><br />
</strong>
</p>
<p>
	<strong>修改，添加</strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/d3262f21b0b742628365f36dc0b7e8fb.jpg" width="578" height="378" alt="" /><br />
</strong>
</p>
<p>
	<strong>主要页面就是这些，使用前后端分离的方式，后端采用nodejs+mongodb,前端采用angularjs</strong>
</p>
<p>
	<strong><br />
</strong>
</p>
<p>
	<strong>下面是项目目录结构</strong>
</p>
<p>
	<strong>angularjs项目结构</strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/564bf6401e9d40939de16ab80f5088db.png" width="364" height="692" alt="" /><br />
</strong>
</p>
<p>
	<strong><br />
</strong>
</p>
<p>
	<strong>nodejs项目结构</strong>
</p>
<p>
	<strong><img src="http://o6n64wdk9.bkt.clouddn.com/0a4fffb44b5844bf909b048b858132a4.png" width="372" height="700" alt="" /><br />
</strong>
</p>
<p>
	<strong><br />
</strong>
</p>
<p>
	<br />
</p>
<p>
	<b><br />
</b>
</p>
<p>
	<b>在这里放上我的github地址，有需要练手的可以下载下来试试</b>
</p>
<p>
	<b>atest:<a href="https://github.com/shangjing105/atest.git" target="_blank">https://github.com/shangjing105/atest.git</a></b>
</p>
<p>
	<strong>ntest:<a href="https://github.com/shangjing105/ntest.git" target="_blank">https://github.com/shangjing105/ntest.git</a></strong>
</p>
<p>
	<br />
</p>
<p>
	<b>暂时说到这里，下次有时间再来补上</b>
</p>