title: 你可以了解下我在Mac上的开发工具和经验
date: '2016-10-21 19:13:16'
updated: '2016-10-31 16:08:54'
tags: [水花, mac, java, 开发工具]
permalink: /articles/2016/10/21/1477048389138.html
---
![工欲善其事，必先利其器](http://o6n64wdk9.bkt.clouddn.com/71a3e8f4911945a7aea6d1d2b0f54a0a.png)


```
工欲善其事，必先利其器。作为一名Java程序员，要提升自己的开发速度，必须要提升自己的工具。
这里分享一些我在mac平台上的开发利器！以及我常浏览的技术网站~
```
# 1.开发利器

**浏览器：**``` Google Chrome```

---

**IDE:：JetBrains**系列全部，不同的语言选择不同的IDE，入java：```IntelliJ IDEA```、前端开发：```WebStrom```，还有```Sublime Text```。强烈推荐大家使用JetBrains系列产品，这里放上一张JetBrains系列产品：

![JetBrains系列产品](http://o6n64wdk9.bkt.clouddn.com/e384bd21eac64c33a1ce3e7f247c08ac.png)

可以满足大部分的开发语言选择。

---

**数据库：**``` Navicat Premium```

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/937221d478eb4e25bf6d45e7edf6d562.png)

---

**接口测试工具：** ```Postman```

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/e75363bb52bf4613b8a5906d3388155f.png)

---

**SSH工具：**  ```iTerm+ Zsh + Oh My Zsh + tmux```（mac版），windows上有```XShell```组合即可。mac上还有```SecurtCRT```。

![iTerm](http://o6n64wdk9.bkt.clouddn.com/52dfb76c8f8a44fa9bfd231c41f71b7c.png)

---

**FTP工具：** ```FileZilla```（mac版）,windows上面百度一下很多

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/9c62967c119945e783dbc2f9cb874d34.png)

---

**远程桌面： ** windows上面自带的就很好，mac上也有远程桌面也比较简单。但是如果是外网访问内网，如果做映射就比较麻烦，这里推荐一个软件：```TeamViewer```
一个两方都安装即可连接，不用ip和密码即可互联。详细可百度

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/6263ca668084416e947b8be19b4124f4.png)

---

**抓包工具：** ```charles```是在 Mac 下常用的网络封包截取工具，在做 [移动开发]时，我们为了调试与服务器端的网络通讯协议，常常需要截取网络封包来分析。

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/e3e3ee1e8930474d939bcbf743f241fd.png)


# 2.效率工具

**Markdown工具：** ```Mou```、```MacDown```

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/5989d56b863545f18745aa978fca0737.png)

---

**桌面邮件软件：** ```Foxmail```

**科学上网工具：** ```ShadowsocksX```科学上网工具

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/0eb478ca8b6f4fc999892331fb67c870.png)

---

**音乐软件：**  必须推荐```网易云音乐```，开发必备。

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/eef48e02f21a4d06b0f4f1d3388972e9.png)

---

**效率工具：**  mac上面的神器```Alfred 2```

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/4df9e95429744c90ac2b92a6eff10dc8.png)

---

**印象笔记：** 工作必备效率应用。

![Paste_Image.png](http://o6n64wdk9.bkt.clouddn.com/063c1c3dd8cd4a0095b504e2f3902acf.png)

---

**Google Chrome插件：** ```Adblock Plus```广告拦截，```Proxy Switchy```系统代理，```JSON Formatter```网页json格式化，```IP域国家国旗```显示网站ip所属国家，```FireShot```网页截图。需要可以去搜索看看


# 3.网站工具

**git网站工具：** ```Gitblit```  [gitblit官网](http://gitblit.com/)

>Gitblit 是一个纯 Java 库用来管理、查看和处理 Git 资料库.相当于 Git 的 Java 管理工具.

**软件跟踪工具：** ```Atlassian JIRA Software```  [中文网站](http://atlassian.csdn.net/)

>JIRA Software是优秀的敏捷项目工具，协助您追踪问题，集成代码，规划，开发，发布高质量的软件产品。

**接口文档工具：** ```Atlassian Confluence```  [中文网站](http://atlassian.csdn.net/)

>Confluence将团队成员紧密的团结在一起，带领团队同心协力地在线编写文档，使团队成员工作更有效率。

**在线部署工具：** ```Jenkins``` [Jenkins官网](https://jenkins.io/)

>Jenkins是一个开源软件项目，旨在提供一个开放易用的软件平台，使软件的持续集成变成可能。Jenkins是基于Java开发的一种持续集成工具，用于监控持续重复的工作


# 4.推荐技术网站

**GitHub：** 全球最大的开源代码仓库。[https://github.com/](https://github.com/)

**Stack Overflow：** [http://stackoverflow.com/](http://stackoverflow.com/)

**简书：**交流故事，沟通想法。一个基于内容分享的社区。[http://www.jianshu.com/](http://www.jianshu.com/)

**开发者头条：** 程序员分享平台。[https://toutiao.io/](https://toutiao.io/)

**掘金：**高质量的技术社区。[http://gold.xitu.io/](http://gold.xitu.io/)

**开源中国：**[http://www.oschina.net/](http://www.oschina.net/)

**CSDN：** [http://www.csdn.net/](http://www.csdn.net/)

**知乎：** [https://www.zhihu.com/](https://www.zhihu.com/)

**推酷：** IT人专属个性阅读社区。 [http://www.tuicool.com/](http://www.tuicool.com/)

---
**还有一些，这里就不一一推荐了。太多也看不过来，有兴趣的可以随意挑选自己喜欢的。**

# 5.结束语

以上的内容就是我在mac平台上使用的工具，还有一些是我的常浏览的技术网站。这里分享出来，希望对大家有益。有什么问题，欢迎随时打扰！

博客:[http://www.shuihua.me](http://www.shuihua.me/)

微信公众号:***水花一现***，***shuihuayixian***

邮箱:***shangjing105@163.com***

Github:[https://github.com/shangjing105](https://github.com/shangjing105)

QQ:***787019494***