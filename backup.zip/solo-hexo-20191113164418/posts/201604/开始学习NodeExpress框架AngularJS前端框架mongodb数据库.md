title: 开始学习Node Express框架，Angular JS前端框架，mongodb数据库
date: '2016-04-27 16:21:28'
updated: '2016-04-27 16:22:31'
tags: [nodejs, angularjs, mongodb]
permalink: /articles/2016/04/27/1461745288696.html
---
<p>1.Node Express框架</p>
<p>2.Angular JS前端框架</p>
<p>3.mongodb文档型数据库</p>