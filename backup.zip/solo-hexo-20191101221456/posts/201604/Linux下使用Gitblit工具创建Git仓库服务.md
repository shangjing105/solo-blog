title: Linux下使用Gitblit工具创建Git仓库服务
date: '2016-04-21 12:34:39'
updated: '2016-04-21 12:34:39'
tags: [Gitblit, Git, Linux]
permalink: /articles/2016/04/21/1461213278866.html
---
<p class="p1"><span class="s1">嗨！朋友，今天我们将学习如何在你的Linux服务器或者PC上安装Gitblit工具。首先，我们看看什么是Git，它的功能以及安装Gitblit的步骤。<a href="http://git-scm.com/"><span class="s2">Git是分布式版本控制系统</span></a>，它强调速度、数据一致性，并且支持分布式、非线性工作流。它最初由Linus Torvalds在2005年为Linux内核设计和开发，使用GPLv2证书，并从此成为软件开发中使用最广泛的版本控制系统。</span></p>
<p class="p1"><span class="s2"><a href="http://gitblit.com/">Gitblit是完全开源的软件</a></span><span class="s1">，它基于纯粹的Java堆栈，被设计以在Git仓库速度和效率方面胜任从小型到极大型的项目。它很容易学习和上手，并有着闪电般的性能。它在很多方面远胜 Subversion、CVS、Perforce和ClearCase等SCM（版本控制）工具，比如，如快速本地分支、易于暂存、多工作流等。</span></p>
<p class="p2">&nbsp;</p>
<p class="p3"><span class="s1"><strong>Gitblit的功能</strong></span></p>
<ul class="ul1">
<li class="li1"><span class="s1">它可以做为一个哑仓库视图，没有管理控制以及用户账户。</span></li>
<li class="li1"><span class="s1">它可以做为完整的Git服务，拥有克隆、推送和仓库访问控制。</span></li>
<li class="li1"><span class="s1">它能独立于其他Git工具使用（包括实际的Git），它能和您已有的工具协作。</span></li>
</ul>
<p class="p4">&nbsp;</p>
<p class="p5"><span class="s5"><strong>1.创建Gitblit安装目录</strong></span></p>
<p class="p1"><span class="s1">首先我们将在我们的服务器上建立一个目录，并在该目录下安装最新的Gitblit。</span></p>
<ol class="ol1">
<li class="li6"><span class="s7">$ </span><span class="s8">sudo</span><span class="s8">mkdir</span><span class="s7"> -p /opt/gitblit</span></li>
<li class="li7"></li>
<li class="li6"><span class="s7">$ </span><span class="s8">cd</span><span class="s7"> /opt/gitblit</span></li>
</ol>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">创建gitblit目录</span></p>
<p class="p4">&nbsp;</p>
<p class="p5"><span class="s5"><strong>2. 下载并解压</strong></span></p>
<p class="p1"><span class="s1">现在，我们将从Gitblit官方站点下载最新版的Gitblit。这里我们将安装1.6.2版本。所以，请在安装时根据具体的版本对命令进行修改。</span></p>
<ol class="ol1">
<li class="li7"><span class="s11">$ </span><span class="s8">sudo</span><span class="s8">wget</span><span class="s11"> http:</span><span class="s7"><em>//dl.bintray.com/gitblit/releases/gitblit-1.6.2.tar.gz</em></span></li>
</ol>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">下载gitblit安装包</span></p>
<p class="p9"><span class="s1">接下来，我们将下载到的tar压缩包解压至之前创建的目录 /opt/gitblit/</span></p>
<ol class="ol1">
<li class="li6"><span class="s7">$ </span><span class="s8">sudo</span><span class="s8">tar</span><span class="s7"> -zxvf gitblit-</span><span class="s12">1.6</span><span class="s7">.</span><span class="s12">2.tar</span><span class="s7">.gz</span></li>
</ol>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">解压gitblit压缩包</span></p>
<p class="p4">&nbsp;</p>
<p class="p5"><span class="s5"><strong>3.配置并运行</strong></span></p>
<p class="p1"><span class="s1">现在，我们将对Gitblit进行配置。如果你想要定制Gitblit的行为，你可以修改</span><span class="s13">gitblit/data/gitblit.properties</span><span class="s1">。在完成配置后，我们将运行安装好的gitblit。有两种方式来运行gitblit，第一种是通过下面的命令手动运行：</span></p>
<ol class="ol1">
<li class="li6"><span class="s7">$ </span><span class="s8">sudo</span><span class="s7"> java -jar gitblit.jar --baseFolder data</span></li>
</ol>
<p class="p1"><span class="s1">另一种是将gitblit添加为服务。下面是在linux下将gitblit添加为服务的步骤。</span></p>
<p class="p1"><span class="s1">由于我在使用Ubuntu，下面的命令将是 sudo cp service-ubuntu.sh /etc/init.d/gitblit，所以请根据你的发行版修改文件名service-ubuntu.sh为相应的你运行的发行版。</span></p>
<ol class="ol1">
<li class="li6"><span class="s7">$ </span><span class="s8">sudo</span><span class="s7"> ./install-service-ubuntu.sh</span></li>
<li class="li7"></li>
<li class="li6"><span class="s7">$ </span><span class="s8">sudo</span><span class="s7"> service gitblit&nbsp; start</span></li>
</ol>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">启动gitblit服务</span></p>
<p class="p9"><span class="s1">在你的浏览器中打开</span><span class="s13">http://localhost:8080</span><span class="s1">或</span><span class="s13">https://localhost:8443</span><span class="s1">，也可以将localhost根据本地配置替换为IP地址。输入默认的管理员凭证：admin / admin并点击login按钮。</span></p>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">gitblit欢迎页面</span></p>
<p class="p9"><span class="s1">现在，我们将添加一个新的用户。首先，你需要以admin用户登录，username =&nbsp;</span><span class="s14"><strong>admin</strong></span><span class="s1">，password =&nbsp;</span><span class="s14"><strong>admin</strong></span><span class="s1">。</span></p>
<p class="p9"><span class="s1">然后，点击用户图标 &gt; users &gt; (+) new user 来创建一个新用户，如下图所示。</span></p>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">添加新用户</span></p>
<p class="p9"><span class="s1">现在，我们将创建一个开箱可用的仓库。点击 repositories &gt; (+) new repository。然后，如下图所示添加新的仓库。</span></p>
<p class="p2">&nbsp;</p>
<p class="p8"><span class="s1">添加新的仓库</span></p>
<p class="p4">&nbsp;</p>
<p class="p3"><span class="s1"><strong>使用命令行创建一个新的仓库</strong></span></p>
<ol class="ol1">
<li class="li6"><span class="s7">&nbsp; &nbsp; </span><span class="s8">touch</span><span class="s7"> README.md</span></li>
<li class="li10"><span class="s16">&nbsp; &nbsp; </span><span class="s17">git</span><span class="s17">init</span></li>
<li class="li6"><span class="s7">&nbsp; &nbsp; </span><span class="s8">git</span><span class="s7"> add README.md</span></li>
<li class="li6"><span class="s7">&nbsp; &nbsp; </span><span class="s8">git</span><span class="s7"> commit -m </span><span class="s18">"first commit"</span></li>
<li class="li7"><span class="s11">&nbsp; &nbsp; </span><span class="s8">git</span><span class="s11"> remote add origin </span><span class="s8">ssh</span><span class="s11">:</span><span class="s7"><em>//arunlinoxide@localhost:29418/linoxide.com.git</em></span></li>
<li class="li6"><span class="s7">&nbsp; &nbsp; </span><span class="s8">git</span><span class="s7"> push -u origin master</span></li>
</ol>
<p class="p1"><span class="s1">请将其中的用户名arunlinoxide替换为你添加的用户名。</span></p>
<p class="p4">&nbsp;</p>
<p class="p3"><span class="s1"><strong>在命令行中push一个已存在的仓库</strong></span></p>
<ol class="ol1">
<li class="li7"><span class="s11">&nbsp; &nbsp; </span><span class="s8">git</span><span class="s11"> remote add origin </span><span class="s8">ssh</span><span class="s11">:</span><span class="s7"><em>//arunlinoxide@localhost:29418/linoxide.com.git</em></span></li>
<li class="li6"><span class="s7">&nbsp; &nbsp; </span><span class="s8">git</span><span class="s7"> push -u origin master</span></li>
</ol>
<p class="p1"><span class="s14"><strong>注意</strong></span><span class="s1">：强烈建议所有人修改用户名&ldquo;admin&rdquo;的密码。</span></p>
<p class="p4">&nbsp;</p>
<p class="p5"><span class="s5"><strong>结论</strong></span></p>
<p class="p1"><span class="s1">欢呼吧！我们已经在Linux电脑中安装好了最新版本的Gitblit。接下来我们便可以在我们的大小项目中享受这样一个优美的版本控制系统。有了Gitblit，版本控制便再容易不过了。它有易于学习、轻量级、高性能的特点。因此，如果你有任何的问题、建议和反馈，请在留言处留言。</span></p>