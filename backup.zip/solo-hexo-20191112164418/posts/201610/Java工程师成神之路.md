title: Java工程师成神之路
date: '2016-10-21 15:47:38'
updated: '2016-10-31 16:08:44'
tags: [java]
permalink: /articles/2016/10/21/1477036058564.html
---
<p><!--?xml version="1.0" encoding="UTF-8"?--></p>
<div>原文链接：<a href="http://www.hollischuang.com/archives/489" target="_blank">http://www.hollischuang.com/archives/489</a></div>
<div>
<div><hr />
<h2>一、基础篇</h2>
<h3>1.1 JVM</h3>
<h4>1.1.1. Java内存模型，Java内存管理，Java堆和栈，垃圾回收</h4>
<blockquote>
<p><span><a href="http://www.jcp.org/en/jsr/detail?id=133">http://www.jcp.org/en/jsr/detail?id=133</a></span></p>
<p><span><a href="http://ifeve.com/jmm-faq/">http://ifeve.com/jmm-faq/</a></span></p>
</blockquote>
<h4>1.1.2. 了解JVM各种参数及调优</h4>
<h4>1.1.3. 学习使用Java工具</h4>
<blockquote>
<p><span><a href="http://www.hollischuang.com/archives/105">jps</a>, <a href="http://www.hollischuang.com/archives/110">jstack</a>, <a href="http://www.hollischuang.com/archives/303">jmap</a>, jconsole, jinfo, jhat, javap, &hellip;</span></p>
<p><span><a href="http://kenai.com/projects/btrace">http://kenai.com/projects/btrace</a></span></p>
<p><span><a href="http://www.crashub.org/">http://www.crashub.org/</a></span></p>
<p><span><a href="https://github.com/taobao/TProfiler">https://github.com/taobao/TProfiler</a></span></p>
<p><span><a href="https://github.com/CSUG/HouseMD">https://github.com/CSUG/HouseMD</a></span></p>
<p><span><a href="https://github.com/CSUG/HouseMD">http://wiki.cyclopsgroup.org/jmxterm</a></span></p>
<p><span><a href="https://github.com/jlusdy/TBJMap">https://github.com/jlusdy/TBJMap</a></span></p>
</blockquote>
<h4>1.1.4. 学习Java诊断工具</h4>
<blockquote>
<p><span><a href="http://www.eclipse.org/mat/">http://www.eclipse.org/mat/</a></span></p>
<p><span><a href="http://visualvm.java.net/oqlhelp.html">http://visualvm.java.net/oqlhelp.html</a></span></p>
</blockquote>
<h4>1.1.5. 自己编写各种outofmemory，stackoverflow程序</h4>
<blockquote>
<p><span>HeapOutOfMemory</span></p>
<p><span>Young OutOfMemory</span></p>
<p><span>MethodArea OutOfMemory</span></p>
<p><span>ConstantPool OutOfMemory</span></p>
<p><span>DirectMemory OutOfMemory</span></p>
<p><span>Stack OutOfMemory Stack OverFlow</span></p>
</blockquote>
<h4>1.1.6. 使用工具尝试解决以下问题，并写下总结</h4>
<blockquote>
<p><span>当一个Java程序响应很慢时如何查找问题 当一个Java程序频繁FullGC时如何解决问题，如何查看垃圾回收日志 当一个Java应用发生OutOfMemory时该如何解决，年轻代、年老代、永久代解决办法不同，导致原因也不同</span></p>
</blockquote>
<h4>1.1.7. 参考资料</h4>
<blockquote>
<p><span><a href="http://docs.oracle.com/javase/specs/jvms/se7/html/">http://docs.oracle.com/javase/specs/jvms/se7/html/</a></span></p>
<p><span><a href="http://www.cs.umd.edu/~pugh/java/memoryModel/">http://www.cs.umd.edu/~pugh/java/memoryModel/</a></span></p>
<p><span><a href="http://gee.cs.oswego.edu/dl/jmm/cookbook.html">http://gee.cs.oswego.edu/dl/jmm/cookbook.html</a></span></p>
<p><span><a href="http://www.guru99.com/java-virtual-machine-jvm.html">http://www.guru99.com/java-virtual-machine-jvm.html</a></span></p>
</blockquote>
<h3>1.2. Java基础知识</h3>
<h4>1.2.1. 阅读源代码</h4>
<blockquote>
<p><code>java.lang.String</code><code>java.lang.Integer`` java.lang.Long</code><code>java.lang.Enum</code><code>java.math.BigDecimal</code><code>java.lang.ThreadLocal</code><code>java.lang.ClassLoader &amp; java.net.URLClassLoader</code><code>java.util.ArrayList &amp; java.util.LinkedList`` java.util.HashMap &amp; java.util.LinkedHashMap &amp; java.util.TreeMap</code><code>java.util.HashSet &amp; java.util.LinkedHashSet &amp; java.util.TreeSet</code></p>
</blockquote>
<h4>1.2.2. 熟悉Java中各种变量类型</h4>
<h4>1.2.3. 熟悉Java String的使用，熟悉String的各种函数</h4>
<h4>1.2.4. 熟悉Java中各种关键字</h4>
<h4>1.2.5. 学会使用List，Map，Stack，Queue，Set</h4>
<blockquote>
<p><span>上述数据结构的遍历 上述数据结构的使用场景 Java实现对</span><code>Array</code><span>/</span><code>List</code><span>排序</span> <code>java.uti.Arrays.sort()</code><code>java.util.Collections.sort()</code> <span>Java实现对List去重 Java实现对List去重，并且需要保留数据原始的出现顺序 Java实现最近最少使用cache，用</span><code>LinkedHashMap</code></p>
</blockquote>
<h4>1.2.6. Java IO&amp;Java NIO，并学会使用</h4>
<blockquote>
<p><code>java.io.*</code><code>java.nio.*</code> <span>nio和reactor设计模式 文件编码，字符集</span></p>
</blockquote>
<h4>1.2.7. Java反射与javassist</h4>
<blockquote>
<p><span>反射与工厂模式</span> <code>java.lang.reflect.*</code></p>
</blockquote>
<h4>1.2.8. Java序列化</h4>
<blockquote>
<p><code>java.io. Serializable</code> <span>什么是序列化，为什么序列化 序列化与单例模式 google序列化protobuf</span></p>
</blockquote>
<h4>1.2.9. 虚引用，弱引用，软引用</h4>
<blockquote>
<p><code>java.lang.ref.*</code> <span>实验这些引用的回收</span></p>
</blockquote>
<h4>1.2.10. 熟悉Java系统属性</h4>
<blockquote>
<p><code>java.util.Properties</code></p>
</blockquote>
<h4>1.2.11. 熟悉Annotation用法</h4>
<blockquote>
<p><code>java.lang.annotation.*</code></p>
</blockquote>
<h4>1.2.12. JMS</h4>
<blockquote>
<p><code>javax.jms.*</code></p>
</blockquote>
<h4>1.2.13. JMX</h4>
<blockquote>
<p><code>java.lang.management.*</code><code>javax.management.*</code></p>
</blockquote>
<h4>1.2.14. 泛型和继承，泛型和擦除</h4>
<h4>1.2.15. 自动拆箱装箱与字节码</h4>
<h4>1.2.16. 实现Callback</h4>
<h4>1.2.17. java.lang.Void类使用</h4>
<h4>1.2.18. Java Agent，premain函数</h4>
<blockquote>
<p><code>java.lang.instrument</code></p>
</blockquote>
<h4>1.2.19. 单元测试</h4>
<blockquote>
<p><span>Junit，<a href="http://junit.org/">http://junit.org/</a></span></p>
<p><span>Jmockit，<a href="https://code.google.com/p/jmockit/">https://code.google.com/p/jmockit/</a></span></p>
<p><span>djUnit，<a href="http://works.dgic.co.jp/djunit/">http://works.dgic.co.jp/djunit/</a></span></p>
</blockquote>
<h4>1.2.20. Java实现通过正则表达式提取一段文本中的电子邮件，并将@替换为#输出</h4>
<blockquote>
<p><code>java.lang.util.regex.*</code></p>
</blockquote>
<h4>1.2.21. 学习使用常用的Java工具库</h4>
<blockquote>
<p><code>commons.lang</code><span>,</span> <code>commons.*...</code><code>guava-libraries</code><code>netty</code></p>
</blockquote>
<h4>1.2.22. 什么是API&amp;SPI</h4>
<blockquote>
<p><span><a href="http://en.wikipedia.org/wiki/Application_programming_interface">http://en.wikipedia.org/wiki/Application_programming_interface</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Service_provider_interface">http://en.wikipedia.org/wiki/Service_provider_interface</a></span></p>
</blockquote>
<h4>1.2.23. 参考资料</h4>
<blockquote>
<p><span>JDK src.zip 源代码</span></p>
<p><span><a href="http://openjdk.java.net/">http://openjdk.java.net/</a></span></p>
<p><span><a href="http://commons.apache.org/">http://commons.apache.org/</a></span></p>
<p><span><a href="https://code.google.com/p/guava-libraries/">https://code.google.com/p/guava-libraries/</a></span></p>
<p><span><a href="http://netty.io/">http://netty.io/</a></span></p>
<p><span><a href="http://stackoverflow.com/questions/2954372/difference-between-spi-and-api">http://stackoverflow.com/questions/2954372/difference-between-spi-and-api</a></span></p>
<p><span><a href="http://stackoverflow.com/questions/11404230/how-to-implement-the-api-spi-pattern-in-java">http://stackoverflow.com/questions/11404230/how-to-implement-the-api-spi-pattern-in-java</a></span></p>
</blockquote>
<h3>1.3. Java并发编程</h3>
<h4>1.3.1. 阅读源代码，并学会使用</h4>
<blockquote>
<p><code>java.lang.Thread</code><code>java.lang.Runnable</code><code>java.util.concurrent.Callable</code><code>java.util.concurrent.locks.ReentrantLock</code><code>java.util.concurrent.locks.ReentrantReadWriteLock</code><code>java.util.concurrent.atomic.Atomic*</code><code>java.util.concurrent.Semaphore</code><code>java.util.concurrent.CountDownLatch</code><code>java.util.concurrent.CyclicBarrier</code><code>java.util.concurrent.ConcurrentHashMap</code><code>java.util.concurrent.Executors</code></p>
</blockquote>
<h4>1.3.2. 学习使用线程池，自己设计线程池需要注意什么</h4>
<h4>1.3.3. 锁</h4>
<blockquote>
<p><span>什么是锁，锁的种类有哪些，每种锁有什么特点，适用场景是什么 在并发编程中锁的意义是什么</span></p>
</blockquote>
<h4>1.3.4. synchronized的作用是什么，synchronized和lock</h4>
<h4>1.3.5. sleep和wait</h4>
<h4>1.3.6. wait和notify</h4>
<h4>1.3.7. 写一个死锁的程序</h4>
<h4>1.3.8. 什么是守护线程，守护线程和非守护线程的区别以及用法</h4>
<h4>1.3.9. volatile关键字的理解</h4>
<blockquote>
<p><span>C++ volatile关键字和Java volatile关键字 happens-before语义 编译器指令重排和CPU指令重排</span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Memory_ordering">http://en.wikipedia.org/wiki/Memory_ordering</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Volatile_variable">http://en.wikipedia.org/wiki/Volatile_variable</a></span></p>
<p><span><a href="http://preshing.com/20130702/the-happens-before-relation/">http://preshing.com/20130702/the-happens-before-relation/</a></span></p>
</blockquote>
<h4>1.3.10. 以下代码是不是线程安全？为什么？如果为count加上volatile修饰是否能够做到线程安全？你觉得该怎么做是线程安全的？</h4>
<pre><code><span><span>public</span></span><span><span>class</span></span><span><span>Sample</span></span><span><span>{</span></span><span><span>private</span></span><span><span>static</span></span><span><span>int</span></span><span><span> count </span></span><span><span>=</span></span><span><span>0</span></span><span><span>;</span></span><span><span>public</span></span><span><span>static</span></span><span><span>void</span></span><span><span> increment</span></span><span><span>()</span></span><span><span>{</span></span><span><span>
    count</span></span><span><span>++;</span></span><span><span>}</span></span><span><span>}</span></span></code></pre>
<h4>1.3.11. 解释一下下面两段代码的差别</h4>
<pre><code><span><span>// 代码1</span></span><span><span>public</span></span><span><span>class</span></span><span><span>Sample</span></span><span><span>{</span></span><span><span>private</span></span><span><span>static</span></span><span><span>int</span></span><span><span> count </span></span><span><span>=</span></span><span><span>0</span></span><span><span>;</span></span><span><span>synchronized</span></span><span><span>public</span></span><span><span>static</span></span><span><span>void</span></span><span><span> increment</span></span><span><span>()</span></span><span><span>{</span></span><span><span>
    count</span></span><span><span>++;</span></span><span><span>}</span></span><span><span>}</span></span><span><span>// 代码2</span></span><span><span>public</span></span><span><span>class</span></span><span><span>Sample</span></span><span><span>{</span></span><span><span>private</span></span><span><span>static</span></span><span><span>AtomicInteger</span></span><span><span> count </span></span><span><span>=</span></span><span><span>new</span></span><span><span>AtomicInteger</span></span><span><span>(</span></span><span><span>0</span></span><span><span>);</span></span><span><span>public</span></span><span><span>static</span></span><span><span>void</span></span><span><span> increment</span></span><span><span>()</span></span><span><span>{</span></span><span><span>
    count</span></span><span><span>.</span></span><span><span>getAndIncrement</span></span><span><span>();</span></span><span><span>}</span></span><span><span>}</span></span></code></pre>
<h4>1.3.12. 参考资料</h4>
<blockquote>
<p><span><a href="http://book.douban.com/subject/10484692/">http://book.douban.com/subject/10484692/</a></span></p>
<p><span><a href="http://www.intel.com/content/www/us/en/processors/architectures-software-developer-manuals.html">http://www.intel.com/content/www/us/en/processors/architectures-software-developer-manuals.html</a></span></p>
</blockquote>
<h2>二、 进阶篇</h2>
<h3>2.1. Java底层知识</h3>
<h4>2.1.1. 学习了解字节码、class文件格式</h4>
<blockquote>
<p><span><a href="http://en.wikipedia.org/wiki/Java_class_file">http://en.wikipedia.org/wiki/Java_class_file</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Java_bytecode">http://en.wikipedia.org/wiki/Java_bytecode</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Java_bytecode_instruction_listings">http://en.wikipedia.org/wiki/Java_bytecode_instruction_listings</a></span></p>
<p><span><a href="http://www.csg.ci.i.u-tokyo.ac.jp/~chiba/javassist/">http://www.csg.ci.i.u-tokyo.ac.jp/~chiba/javassist/</a></span></p>
<p><span><a href="http://asm.ow2.org/">http://asm.ow2.org/</a></span></p>
</blockquote>
<h4>2.1.2. 写一个程序要求实现javap的功能（手工完成，不借助ASM等工具）</h4>
<p><span><span><span>如Java源代码：</span></span></span></p>
<pre><code><span><span>public</span></span><span><span>static</span></span><span><span>void</span></span><span><span> main</span></span><span><span>(</span></span><span><span>String</span></span><span><span>[]</span></span><span><span> args</span></span><span><span>)</span></span><span><span>{</span></span><span><span>int</span></span><span><span> i </span></span><span><span>=</span></span><span><span>0</span></span><span><span>;</span></span><span><span>
    i </span></span><span><span>+=</span></span><span><span>1</span></span><span><span>;</span></span><span><span>
    i </span></span><span><span>*=</span></span><span><span>1</span></span><span><span>;</span></span><span><span>System</span></span><span><span>.</span></span><span><span>out</span></span><span><span>.</span></span><span><span>println</span></span><span><span>(</span></span><span><span>i</span></span><span><span>);</span></span><span><span>}</span></span></code></pre>
<p><span><span><span>编译后读取class文件输出以下代码：</span></span></span></p>
<pre><code><span><span>public</span></span><span><span>static</span></span><span><span>void</span></span><span><span> main</span></span><span><span>(</span></span><span><span>java</span></span><span><span>.</span></span><span><span>lang</span></span><span><span>.</span></span><span><span>String</span></span><span><span>[]);</span></span><span><span>Code</span></span><span><span>:</span></span><span><span>Stack</span></span><span><span>=</span></span><span><span>2</span></span><span><span>,</span></span><span><span>Locals</span></span><span><span>=</span></span><span><span>2</span></span><span><span>,</span></span><span><span>Args_size</span></span><span><span>=</span></span><span><span>1</span></span><span><span>0</span></span><span><span>:</span></span><span><span>   iconst_0
   </span></span><span><span>1</span></span><span><span>:</span></span><span><span>   istore_1
   </span></span><span><span>2</span></span><span><span>:</span></span><span><span>   iinc    </span></span><span><span>1</span></span><span><span>,</span></span><span><span>1</span></span><span><span>5</span></span><span><span>:</span></span><span><span>   iload_1
   </span></span><span><span>6</span></span><span><span>:</span></span><span><span>   iconst_1
   </span></span><span><span>7</span></span><span><span>:</span></span><span><span>   imul
   </span></span><span><span>8</span></span><span><span>:</span></span><span><span>   istore_1
   </span></span><span><span>9</span></span><span><span>:</span></span><span><span>   getstatic       </span></span><span><span>#2; //Field java/lang/System.out:Ljava/io/PrintStream;</span></span><span><span>12</span></span><span><span>:</span></span><span><span>  iload_1
   </span></span><span><span>13</span></span><span><span>:</span></span><span><span>  invokevirtual   </span></span><span><span>#3; //Method java/io/PrintStream.println:(I)V</span></span><span><span>16</span></span><span><span>:</span></span><span><span>return</span></span><span><span>LineNumberTable</span></span><span><span>:</span></span><span><span> 
   line </span></span><span><span>4</span></span><span><span>:</span></span><span><span>0</span></span><span><span>
   line </span></span><span><span>5</span></span><span><span>:</span></span><span><span>2</span></span><span><span>
   line </span></span><span><span>6</span></span><span><span>:</span></span><span><span>5</span></span><span><span>
   line </span></span><span><span>7</span></span><span><span>:</span></span><span><span>9</span></span><span><span>
   line </span></span><span><span>8</span></span><span><span>:</span></span><span><span>16</span></span></code></pre>
<h4>2.1.3. CPU缓存，L1，L2，L3和伪共享</h4>
<blockquote>
<p><span><a href="http://duartes.org/gustavo/blog/post/intel-cpu-caches/">http://duartes.org/gustavo/blog/post/intel-cpu-caches/</a></span></p>
<p><span><a href="http://mechanical-sympathy.blogspot.com/2011/07/false-sharing.html">http://mechanical-sympathy.blogspot.com/2011/07/false-sharing.html</a></span></p>
</blockquote>
<h4>2.1.4. 什么是尾递归</h4>
<h4>2.1.5. 熟悉位运算</h4>
<blockquote>
<p><span>用位运算实现加、减、乘、除、取余</span></p>
</blockquote>
<h4>2.1.6. 参考资料</h4>
<blockquote>
<p><span><a href="http://book.douban.com/subject/1138768/">http://book.douban.com/subject/1138768/</a></span></p>
<p><span><a href="http://book.douban.com/subject/6522893/">http://book.douban.com/subject/6522893/</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Java_class_file">http://en.wikipedia.org/wiki/Java_class_file</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Java_bytecode">http://en.wikipedia.org/wiki/Java_bytecode</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Java_bytecode_instruction_listings">http://en.wikipedia.org/wiki/Java_bytecode_instruction_listings</a></span></p>
</blockquote>
<h3>2.2. 设计模式</h3>
<h4>2.2.1. 实现AOP</h4>
<blockquote>
<p><span>CGLIB和InvocationHandler的区别 <a href="http://cglib.sourceforge.net/">http://cglib.sourceforge.net/</a></span></p>
<p><span>动态代理模式 Javassist实现AOP <a href="http://www.csg.ci.i.u-tokyo.ac.jp/~chiba/javassist/">http://www.csg.ci.i.u-tokyo.ac.jp/~chiba/javassist/</a></span></p>
<p><span>ASM实现AOP <a href="http://asm.ow2.org/">http://asm.ow2.org/</a></span></p>
</blockquote>
<h4>2.2.2. 使用模板方法设计模式和策略设计模式实现IOC</h4>
<h4>2.2.3. 不用synchronized和lock，实现线程安全的单例模式</h4>
<h4>2.2.4. nio和reactor设计模式</h4>
<h4>2.2.5. 参考资料</h4>
<blockquote>
<p><span><a href="http://asm.ow2.org/">http://asm.ow2.org/</a></span></p>
<p><span><a href="http://cglib.sourceforge.net/">http://cglib.sourceforge.net/</a></span></p>
<p><span><a href="http://www.javassist.org/">http://www.javassist.org/</a></span></p>
</blockquote>
<h3>2.3. 网络编程知识</h3>
<h4>2.3.1. Java RMI，Socket，HttpClient</h4>
<h4>2.3.2. 用Java写一个简单的静态文件的HTTP服务器</h4>
<blockquote>
<p><span>实现客户端缓存功能，支持返回304 实现可并发下载一个文件 使用线程池处理客户端请求 使用nio处理客户端请求 支持简单的rewrite规则 上述功能在实现的时候需要满足&ldquo;开闭原则&rdquo;</span></p>
</blockquote>
<h4>2.3.3. 了解nginx和apache服务器的特性并搭建一个对应的服务器</h4>
<blockquote>
<p><span><a href="http://nginx.org/">http://nginx.org/</a></span></p>
<p><span><a href="http://httpd.apache.org/">http://httpd.apache.org/</a></span></p>
</blockquote>
<h4>2.3.4. 用Java实现FTP、SMTP协议</h4>
<h4>2.3.5. 什么是CDN？如果实现？DNS起到什么作用？</h4>
<blockquote>
<p><span>搭建一个DNS服务器 搭建一个 Squid 或 Apache Traffic Server 服务器 <a href="http://www.squid-cache.org/">http://www.squid-cache.org/</a> <a href="http://trafficserver.apache.org/">http://trafficserver.apache.org/</a> <a href="http://en.wikipedia.org/wiki/Domain_Name_System">http://en.wikipedia.org/wiki/Domain_Name_System</a></span></p>
</blockquote>
<h4>2.3.6. 参考资料</h4>
<blockquote>
<p><span><a href="http://www.ietf.org/rfc/rfc2616.txt">http://www.ietf.org/rfc/rfc2616.txt</a></span></p>
<p><span><a href="http://tools.ietf.org/rfc/rfc5321.txt">http://tools.ietf.org/rfc/rfc5321.txt</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Open/closed_principle">http://en.wikipedia.org/wiki/Open/closed_principle</a></span></p>
</blockquote>
<h3>2.4. 框架知识</h3>
<blockquote>
<p><span>spring，spring mvc，阅读主要源码 ibatis，阅读主要源码 用spring和ibatis搭建java server</span></p>
</blockquote>
<h3>2.5. 应用服务器知识</h3>
<blockquote>
<p><span>熟悉使用jboss，<a href="https://www.jboss.org/overview/">https://www.jboss.org/overview/</a> 熟悉使用tomcat，<a href="http://tomcat.apache.org/">http://tomcat.apache.org/</a> 熟悉使用jetty，<a href="http://www.eclipse.org/jetty/">http://www.eclipse.org/jetty/</a></span></p>
</blockquote>
<h2>三、 高级篇</h2>
<h3>3.1. 编译原理知识</h3>
<h4>3.1.1. 用Java实现以下表达式解析并返回结果（语法和Oracle中的select sysdate-1 from dual类似）</h4>
<pre><code><span><span> sysdate
 sysdate </span></span><span><span>-</span></span><span><span>1</span></span><span><span>
 sysdate </span></span><span><span>-</span></span><span><span>1</span></span><span><span>/</span></span><span><span>24</span></span><span><span>
 sysdate </span></span><span><span>-</span></span><span><span>1</span></span><span><span>/(</span></span><span><span>12</span></span><span><span>*</span></span><span><span>2</span></span><span><span>)</span></span></code></pre>
<h4>3.1.2. 实现对一个List通过DSL筛选</h4>
<pre><code><span><span>QList</span></span><span><span>&lt;</span></span><span><span>Map</span></span><span><span>&lt;</span></span><span><span>String</span></span><span><span>,</span></span><span><span>Object</span></span><span><span>&gt;&gt;</span></span><span><span> mapList </span></span><span><span>=</span></span><span><span>new</span></span><span><span>QList</span></span><span><span>&lt;</span></span><span><span>Map</span></span><span><span>&lt;</span></span><span><span>String</span></span><span><span>,</span></span><span><span>Object</span></span><span><span>&gt;&gt;;</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>add</span></span><span><span>({</span></span><span><span>"name"</span></span><span><span>:</span></span><span><span>"hatter test"</span></span><span><span>});</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>add</span></span><span><span>({</span></span><span><span>"id"</span></span><span><span>:</span></span><span><span>-</span></span><span><span>1</span></span><span><span>,</span></span><span><span>"name"</span></span><span><span>:</span></span><span><span>"hatter test"</span></span><span><span>});</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>add</span></span><span><span>({</span></span><span><span>"id"</span></span><span><span>:</span></span><span><span>0</span></span><span><span>,</span></span><span><span>"name"</span></span><span><span>:</span></span><span><span>"hatter test"</span></span><span><span>});</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>add</span></span><span><span>({</span></span><span><span>"id"</span></span><span><span>:</span></span><span><span>1</span></span><span><span>,</span></span><span><span>"name"</span></span><span><span>:</span></span><span><span>"test test"</span></span><span><span>});</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>add</span></span><span><span>({</span></span><span><span>"id"</span></span><span><span>:</span></span><span><span>2</span></span><span><span>,</span></span><span><span>"name"</span></span><span><span>:</span></span><span><span>"hatter test"</span></span><span><span>});</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>add</span></span><span><span>({</span></span><span><span>"id"</span></span><span><span>:</span></span><span><span>3</span></span><span><span>,</span></span><span><span>"name"</span></span><span><span>:</span></span><span><span>"test hatter"</span></span><span><span>});</span></span><span><span>
  mapList</span></span><span><span>.</span></span><span><span>query</span></span><span><span>(</span></span><span><span>"id is not null and id &gt; 0 and name like '%hatter%'"</span></span><span><span>);</span></span></code></pre>
<p><span><span><span>要求返回列表中匹配的对象，即最后两个对象；</span></span></span></p>
<h4>3.1.3. 用Java实现以下程序（语法和变量作用域处理都和JavaScript类似）：</h4>
<p><span><span><span>代码：</span></span></span></p>
<pre><code><span><span>var</span></span><span><span> a </span></span><span><span>=</span></span><span><span>1</span></span><span><span>;</span></span><span><span>var</span></span><span><span> b </span></span><span><span>=</span></span><span><span>2</span></span><span><span>;</span></span><span><span>var</span></span><span><span> c </span></span><span><span>=</span></span><span><span>function</span></span><span><span>()</span></span><span><span>{</span></span><span><span>var</span></span><span><span> a </span></span><span><span>=</span></span><span><span>3</span></span><span><span>;</span></span><span><span>
  println</span></span><span><span>(</span></span><span><span>a</span></span><span><span>);</span></span><span><span>
  println</span></span><span><span>(</span></span><span><span>b</span></span><span><span>);</span></span><span><span>};</span></span><span><span>
c</span></span><span><span>();</span></span><span><span>
println</span></span><span><span>(</span></span><span><span>a</span></span><span><span>);</span></span><span><span>
println</span></span><span><span>(</span></span><span><span>b</span></span><span><span>);</span></span></code></pre>
<p><span><span><span>输出：</span></span></span></p>
<pre><code><span><span>3</span></span><span><span>2</span></span><span><span>1</span></span><span><span>2</span></span></code></pre>
<h4>3.1.4. 参考资料</h4>
<blockquote>
<p><span>http://en.wikipedia.org/wiki/Abstract_syntax_tree https://javacc.java.net/ http://www.antlr.org/</span></p>
</blockquote>
<h3>3.2. 操作系统知识</h3>
<blockquote>
<p><span>Ubuntu Centos 使用linux，熟悉shell脚本</span></p>
</blockquote>
<h3>3.3. 数据存储知识</h3>
<h4>3.3.1. 关系型数据库</h4>
<blockquote>
<p><span>MySQL 如何看执行计划 如何搭建MySQL主备 binlog是什么 Derby，H2，PostgreSQL SQLite</span></p>
</blockquote>
<h3>3.3.2. NoSQL</h3>
<blockquote>
<p><span>Cache Redis Memcached Leveldb Bigtable HBase Cassandra Mongodb 图数据库 neo4j</span></p>
</blockquote>
<h3>3.3.3. 参考资料</h3>
<blockquote>
<p><span><a href="http://db-engines.com/en/ranking">http://db-engines.com/en/ranking</a></span></p>
<p><span><a href="http://redis.io/">http://redis.io/</a></span></p>
<p><span><a href="https://code.google.com/p/leveldb/">https://code.google.com/p/leveldb/</a></span></p>
<p><span><a href="http://hbase.apache.org/">http://hbase.apache.org/</a></span></p>
<p><span><a href="http://cassandra.apache.org/">http://cassandra.apache.org/</a></span></p>
<p><span><a href="http://www.mongodb.org/">http://www.mongodb.org/</a></span></p>
<p><span><a href="http://www.mongodb.org/">http://www.neo4j.org/</a></span></p>
</blockquote>
<h3>3.4. 大数据知识</h3>
<h4>3.4.1. Zookeeper，在linux上部署zk</h4>
<h4>3.4.2. Solr，Lucene，ElasticSearch</h4>
<blockquote>
<p><span>在linux上部署solr，solrcloud，，新增、删除、查询索引</span></p>
</blockquote>
<h4>3.4.3. Storm，流式计算，了解Spark，S4</h4>
<blockquote>
<p><span>在linux上部署storm，用zookeeper做协调，运行storm hello world，local和remote模式运行调试storm topology。</span></p>
</blockquote>
<h4>3.4.4. Hadoop，离线计算</h4>
<blockquote>
<p><span>Hdfs：部署NameNode，SecondaryNameNode，DataNode，上传文件、打开文件、更改文件、删除文件</span></p>
<p><span>MapReduce：部署JobTracker，TaskTracker，编写mr job</span></p>
<p><span>Hive：部署hive，书写hive sql，得到结果</span></p>
<p><span>Presto：类hive，不过比hive快，非常值得学习</span></p>
</blockquote>
<h4>3.4.5. 分布式日志收集flume，kafka，logstash</h4>
<h4>3.4.6. 数据挖掘，mahout</h4>
<h4>3.4.7. 参考资料</h4>
<blockquote>
<p><span><a href="http://zookeeper.apache.org/">http://zookeeper.apache.org/</a></span></p>
<p><span><a href="https://lucene.apache.org/solr/">https://lucene.apache.org/solr/</a></span></p>
<p><span><a href="https://github.com/nathanmarz/storm/wiki">https://github.com/nathanmarz/storm/wiki</a></span></p>
<p><span><a href="http://hadoop.apache.org/">http://hadoop.apache.org/</a></span></p>
<p><span><a href="http://prestodb.io/">http://prestodb.io/</a></span></p>
<p><span><a href="http://flume.apache.org/">http://flume.apache.org/</a></span></p>
<p><span><a href="http://logstash.net/">http://logstash.net/</a></span></p>
<p><span><a href="http://kafka.apache.org/">http://kafka.apache.org/</a></span></p>
<p><span><a href="http://mahout.apache.org/">http://mahout.apache.org/</a></span></p>
</blockquote>
<h3>3.5. 网络安全知识</h3>
<h4>3.5.1. 什么是DES、AES</h4>
<h4>3.5.2. 什么是RSA、DSA</h4>
<h4>3.5.3. 什么是MD5，SHA1</h4>
<h4>3.5.4. 什么是SSL、TLS，为什么HTTPS相对比较安全</h4>
<h4>3.5.5. 什么是中间人攻击、如果避免中间人攻击</h4>
<h4>3.5.6. 什么是DOS、DDOS、CC攻击</h4>
<h4>3.5.7. 什么是CSRF攻击</h4>
<h4>3.5.8. 什么是CSS攻击</h4>
<h4>3.5.9. 什么是SQL注入攻击</h4>
<h4>3.5.10. 什么是Hash碰撞拒绝服务攻击</h4>
<h4>3.5.11. 了解并学习下面几种增强安全的技术</h4>
<blockquote>
<p><span>http://www.openauthentication.org/</span></p>
<p><span>HOTP http://www.ietf.org/rfc/rfc4226.txt</span></p>
<p><span>TOTP http://tools.ietf.org/rfc/rfc6238.txt</span></p>
<p><span>OCRA http://tools.ietf.org/rfc/rfc6287.txt</span></p>
<p><span>http://en.wikipedia.org/wiki/Salt_(cryptography)</span></p>
</blockquote>
<h4>3.5.12. 用openssl签一个证书部署到apache或nginx</h4>
<h4>3.5.13. 参考资料</h4>
<blockquote>
<p><span><a href="http://en.wikipedia.org/wiki/Cryptographic_hash_function">http://en.wikipedia.org/wiki/Cryptographic_hash_function</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Block_cipher">http://en.wikipedia.org/wiki/Block_cipher</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Public-key_cryptography">http://en.wikipedia.org/wiki/Public-key_cryptography</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/Transport_Layer_Security">http://en.wikipedia.org/wiki/Transport_Layer_Security</a></span></p>
<p><span><a href="http://www.openssl.org/">http://www.openssl.org/</a></span></p>
<p><span><a href="https://code.google.com/p/google-authenticator/">https://code.google.com/p/google-authenticator/</a></span></p>
</blockquote>
<h2>四、 扩展篇</h2>
<h3>4.1. 相关知识</h3>
<h4>4.1.1. 云计算，分布式，高可用，可扩展</h4>
<h4>4.1.2. 虚拟化</h4>
<blockquote>
<p><span><a href="https://linuxcontainers.org/">https://linuxcontainers.org/</a></span></p>
<p><span><a href="http://www.linux-kvm.org/page/Main_Page">http://www.linux-kvm.org/page/Main_Page</a></span></p>
<p><span><a href="http://www.xenproject.org/">http://www.xenproject.org/</a></span></p>
<p><span><a href="https://www.docker.io/">https://www.docker.io/</a></span></p>
</blockquote>
<h4>4.1.3. 监控</h4>
<blockquote>
<p><span><a href="http://www.nagios.org/">http://www.nagios.org/</a></span></p>
<p><span><a href="http://ganglia.info/">http://ganglia.info/</a></span></p>
</blockquote>
<h4>4.1.4. 负载均衡</h4>
<blockquote>
<p><span><a href="http://www.linuxvirtualserver.org/">http://www.linuxvirtualserver.org/</a></span></p>
</blockquote>
<h4>4.1.5. 学习使用git</h4>
<blockquote>
<p><span><a href="https://github.com/">https://github.com/</a></span></p>
<p><span><a href="https://git.oschina.net/">https://git.oschina.net/</a></span></p>
</blockquote>
<h4>4.1.6. 学习使用maven</h4>
<blockquote>
<p><span><a href="http://maven.apache.org/">http://maven.apache.org/</a></span></p>
</blockquote>
<h4>4.1.7. 学习使用gradle</h4>
<blockquote>
<p><span><a href="http://www.gradle.org/">http://www.gradle.org/</a></span></p>
</blockquote>
<h4>4.1.8. 学习一个小语种语言</h4>
<blockquote>
<p><span>Groovy Scala LISP, Common LISP, Schema, Clojure R Julia Lua Ruby</span></p>
</blockquote>
<h4>4.1.9. 尝试了解编码的本质</h4>
<blockquote>
<p><span>了解以下概念 ASCII, ISO-8859-1 GB2312, GBK, GB18030 Unicode, UTF-8 不使用 String.getBytes() 等其他工具类/函数完成下面功能</span></p>
</blockquote>
<pre><code><span><span>public</span></span><span><span>static</span></span><span><span>void</span></span><span><span> main</span></span><span><span>(</span></span><span><span>String</span></span><span><span>[]</span></span><span><span> args</span></span><span><span>)</span></span><span><span>throws</span></span><span><span>IOException</span></span><span><span>{</span></span><span><span>String</span></span><span><span> str </span></span><span><span>=</span></span><span><span>"Hello, 我们是中国人。"</span></span><span><span>;</span></span><span><span>byte</span></span><span><span>[]</span></span><span><span> utf8Bytes </span></span><span><span>=</span></span><span><span> toUTF8Bytes</span></span><span><span>(</span></span><span><span>str</span></span><span><span>);</span></span><span><span>FileOutputStream</span></span><span><span> fos </span></span><span><span>=</span></span><span><span>new</span></span><span><span>FileOutputStream</span></span><span><span>(</span></span><span><span>"f.txt"</span></span><span><span>);</span></span><span><span>
    fos</span></span><span><span>.</span></span><span><span>write</span></span><span><span>(</span></span><span><span>utf8Bytes</span></span><span><span>);</span></span><span><span>
    fos</span></span><span><span>.</span></span><span><span>close</span></span><span><span>();</span></span><span><span>}</span></span><span><span>public</span></span><span><span>static</span></span><span><span>byte</span></span><span><span>[]</span></span><span><span> toUTF8Bytes</span></span><span><span>(</span></span><span><span>String</span></span><span><span> str</span></span><span><span>)</span></span><span><span>{</span></span><span><span>return</span></span><span><span>null</span></span><span><span>;</span></span><span><span>// TODO</span></span><span><span>}</span></span></code></pre>
<blockquote>
<p><span>想一下上面的程序能不能写一个转GBK的？ 写个程序自动判断一个文件是哪种编码</span></p>
</blockquote>
<h4>4.1.10. 尝试了解时间的本质</h4>
<blockquote>
<p><span>时区 &amp; 冬令时、夏令时 <a href="http://en.wikipedia.org/wiki/Time_zone">http://en.wikipedia.org/wiki/Time_zone</a> <a href="http://www.hollischuang.com/archives/489ftp://ftp.iana.org/tz/data/asia">ftp://ftp.iana.org/tz/data/asia</a> <a href="http://zh.wikipedia.org/wiki/%E4%B8%AD%E5%9C%8B%E6%99%82%E5%8D%80">http://zh.wikipedia.org/wiki/%E4%B8%AD%E5%9C%8B%E6%99%82%E5%8D%80</a></span></p>
<p><span>闰年 <a href="http://en.wikipedia.org/wiki/Leap_year">http://en.wikipedia.org/wiki/Leap_year</a></span></p>
<p><span>闰秒 <a href="http://www.hollischuang.com/archives/489ftp://ftp.iana.org/tz/data/leapseconds">ftp://ftp.iana.org/tz/data/leapseconds</a></span></p>
<p><code>System.currentTimeMillis()</code> <span>返回的时间是什么</span></p>
</blockquote>
<h4>4.1.11. 参考资料</h4>
<blockquote>
<p><span><a href="http://git-scm.com/">http://git-scm.com/</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/UTF-8">http://en.wikipedia.org/wiki/UTF-8</a></span></p>
<p><span><a href="http://en.wikipedia.org/wiki/UTF-8">http://www.iana.org/time-zones</a></span></p>
</blockquote>
<h3>4.2. 扩展学习</h3>
<h4>4.2.1. JavaScript知识</h4>
<h5>4.2.1.1. 什么是prototype</h5>
<blockquote>
<p><span>修改代码，使程序输出&ldquo;1 3 5&rdquo;： <a href="http://jsfiddle.net/Ts7Fk/">http://jsfiddle.net/Ts7Fk/</a></span></p>
</blockquote>
<h5>4.2.1.2. 什么是闭包</h5>
<blockquote>
<p><span>看一下这段代码，并解释一下为什么按Button1时没有alert出&ldquo;This is button: 1&rdquo;，如何修改： <a href="http://jsfiddle.net/FDPj3/1/">http://jsfiddle.net/FDPj3/1/</a></span></p>
</blockquote>
<h5>4.2.1.3. 了解并学习一个JS框架</h5>
<blockquote>
<p><span>jQuery ExtJS ArgularJS</span></p>
</blockquote>
<h5>4.2.1.4. 写一个Greasemonkey插件</h5>
<pre><code><span><span>http</span></span><span><span>:</span></span><span><span>//en.wikipedia.org/wiki/Greasemonkey</span></span></code></pre>
<h5>4.2.1.5. 学习node.js</h5>
<blockquote>
<p><span><a href="http://jsfiddle.net/FDPj3/1/">http://nodejs.org/</a></span></p>
</blockquote>
<h4>4.2.2. 学习html5</h4>
<blockquote>
<p><span>ArgularJS，<a href="https://docs.angularjs.org/api">https://docs.angularjs.org/api</a></span></p>
</blockquote>
<h4>4.2.3. 参考资料</h4>
<blockquote>
<p><span><a href="http://www.ecmascript.org/">http://www.ecmascript.org/</a></span></p>
<p><span><a href="http://jsfiddle.net/">http://jsfiddle.net/</a></span></p>
<p><span><a href="http://jsbin.com/">http://jsbin.com/</a></span></p>
<p><span><a href="http://runjs.cn/">http://runjs.cn/</a></span></p>
<p><span><a href="http://runjs.cn/">http://userscripts.org/</a></span></p>
</blockquote>
<h2>五、 推荐书籍</h2>
<blockquote>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DZvRvWHu6SOnuDAZjWhpTWAqt5sjBXAKAeCkqdCFDLOxBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLRYEUmnvjajAg%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《深入Java虚拟机》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DruMSq37OOfbuDAZjWhpTWAqt5sjBXAKAeCkqdCFDLOxBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLTIpZdTC6RHCA%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《深入理解Java虚拟机》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DXNiOKJpiO7TuDAZjWhpTWDaAZ8A7vIffKo6rHv51kdtBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLSqMCmgzjxR%252BQ%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《Effective Java》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DUTVfosmcpeW6k0Or%252B%252BH4tHI7U6uhyhd5ENbBVuy6U6CLltG5xFicOdXrTUTgh9sMDPIwxrc30rg%252Bti0P%252FwKUmz9rLA8dYnymkYuN890a%252Fa8F2i6YdfNn1lRmtaud%252B0v%252Bt5z%252BDtPo5eXZSYdm6WZA2w%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《七周七语言》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3D8E0ZFkGCa4nuDAZjWhpTWIH%252BZP%252FBKjMYaRpVLarZ1rdBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLTmCHcueORLqw%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《七周七数据》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DX2wRRnOMgffuDAZjWhpTWCGSPR3bshuFJQ5oPTLBF1NBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLSHNzbOReZhTA%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《Hadoop技术内幕》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3Dl9hhJRCCD9nebLdhAWchHLbUU0JZj4TW1BHSvcRrnkWLltG5xFicOdXrTUTgh9sMDPIwxrc30rg%252Bti0P%252FwKUmz9rLA8dYnymkYuN890a%252Fa8F2i6YdfNn1lRmtaud%252B0v%252Bt5z%252BDtPo5eUhCRMIlenyaA%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《Hbase In Action》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DBqy%252Fse2OntzghojqVNxKsfE0PFzNEA7q8HgNo8uZfyqLltG5xFicOdXrTUTgh9sMDPIwxrc30rg%252Bti0P%252FwKUmz9rLA8dYnymkYuN890a%252Fa8F2i6YdfNn1lRmtaud%252B0v%252Bt5z%252BDtPo5eXxMS9zg13LJg%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《Mahout In Action》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3Dw95piRGiFybuDAZjWhpTWGdkho7Gvmakc5n8OCikHcNBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLTsOzyxQ6nLQA%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《这就是搜索引擎》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DiuMmiSYV%252BobghojqVNxKsZdy6yFShhOriLSVUC%252FYQraLltG5xFicOdXrTUTgh9sMDPIwxrc30rg%252Bti0P%252FwKUmz9rLA8dYnymkYuN890a%252Fa8F2i6YdfNn1lRmtaud%252B0v%252Bt5z%252BDtPo5eV7QtacfFHhKQ%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《Solr In Action》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DMkmsPHOlBQXuDAZjWhpTWEDeIpay%252FCpUxDf4a6L3B5VBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLStvh1VudKGNw%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《深入分析Java Web技术内幕》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DQNSw6jWKnzLuDAZjWhpTWJFwhKp5ZMJT%252FFY2y45CqT5BWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLQ7kLHNSG8FRg%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《大型网站技术架构》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DCZ6zy4IdlJDuDAZjWhpTWNAcKbFgIMNwzqUbDwbgWitBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLS9VMwrtHHGbA%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《高性能MySQL》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DXV4hpKdYaIjuDAZjWhpTWBZ3v%252F21wroSrQw8YMeO7klBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLRkzTznPcS%252Bmw%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《算法导论》</a></span></p>
<p><span>《计算机程序设计艺术》</span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3D3QbaGr66%252BlruDAZjWhpTWMYVYqDsaRju%252BGm%252FBL973ipBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLSLnr%252BCukWK0w%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《代码大全》</a></span></p>
<p><span><a href="http://redirect.simba.taobao.com/rd?w=unionnojs&amp;f=http%3A%2F%2Fai.taobao.com%2Fauction%2Fedetail.htm%3Fe%3DtKN1RkDQOXruDAZjWhpTWKUvOcPeTa0lQbkDIVMzTDZBWJVBnwmj7tnO073KpEUuesayvrQ7hvm50VDmyluWgoBcpW0hhVAnj0d7jq0J5nxS0CLDc%252BkBd%252FlYGH3A75GKYDUMsRn%252FRLSjIPjO6CMcTQ%253D%253D%26ptype%3D100010%26from%3Dbasic&amp;k=5ccfdb950740ca16&amp;c=un&amp;b=alimm_0&amp;p=mm_42606752_12122458_44532463">《JavaScript权威指南》</a></span></p>
</blockquote>
<div>&nbsp;</div>
</div>
</div>