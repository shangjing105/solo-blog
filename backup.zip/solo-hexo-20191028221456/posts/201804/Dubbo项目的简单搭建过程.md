title: Dubbo项目的简单搭建过程
date: '2018-04-18 11:30:35'
updated: '2018-06-22 15:36:10'
tags: [java, dubbo]
permalink: /articles/2018/05/16/1526527835087.html
---
![](https://img.hacpai.com/bing/20180321.jpg?imageView2/1/w/960/h/520/interlace/1/q/100) 



> 由于这段时间一直在微服务进行实践，过程中尝试用dubbo作为rpc框架搭建了一个简单的项目，下面给大家简单说明下这个项目。

项目在github上的地址：[https://github.com/shangjing105/dubbo](https://github.com/shangjing105/dubbo)

## dubbo介绍&&项目简介

1. Dubbo是一个分布式服务框架，以及SOA治理方案。其功能主要包括：高性能NIO通讯及多协议集成，服务动态寻址与路由，软负载均衡与容错，依赖分析与降级等。 

2. Dubbo官网：[http://dubbo.apache.org/](http://dubbo.apache.org/)，官网上有关于dubbo的一些项目和jar包资源下载。

3. 项目使用的是springboot架构，可以进行快速开发。

4. 项目分为3个模块，分别为服务提供者，消费者，API接口层。

5. 使用zookeeper作为注册中心


## provide服务提供者

provide服务提供者，对外提供服务接口。这个项目里提供者即使提供者也是消费者。

1. 加入Jar包

```xml
        <dependency>
 			<groupId>com.alibaba</groupId>
 			<artifactId>dubbo</artifactId>
 			<version>2.6.0</version>
 		</dependency>
 		<dependency>
 			<groupId>org.apache.zookeeper</groupId>
 			<artifactId>zookeeper</artifactId>
 			<version>3.4.6</version>
 		</dependency>
 		
```

2. 配置服务提供者

```xml
     <!-- 提供方应用信息，用于计算依赖关系 -->
     <dubbo:application name="${dubbo.application.name}" />
     <!-- 注册中心暴露服务地址 -->
     <dubbo:registry protocol="${dubbo.registry.protocol}" address="${dubbo.registry.address}" />
     <!-- 暴露服务方式和端口 -->
     <dubbo:protocol name="${dubbo.protocol.name}" port="${dubbo.protocol.port}" />
     <!-- 服务提供者 -->
     <dubbo:service interface="com.hejia.api.service.UserService" ref="userServiceImpl" version="1.0.0" timeout="600" />
     <!-- 服务消费者 -->
     <dubbo:reference interface="com.hejia.api.service.UserService" id="userService" version="1.0.0" check="false"/>
```

这里需要注意的是在注入提供者和消费者的时候要注意ref与id要对应不同的实例化对象。

3. 配置

```properties
#应用名称
dubbo.application.name=pisces-provider
#注册中心类型
dubbo.registry.protocol=zookeeper
#注册中心地址
dubbo.registry.address=127.0.0.1:2181
#暴露服务方式
dubbo.protocol.name=dubbo
#暴露服务端口
dubbo.protocol.port=18020
```

配置完这些后，其他地方的代码都正常开发流程一样，对代码的侵入性很小，只需加入少量的配置文件，即可实现功能分布式rpc调用。

相关代码可以看我项目里的实现。

## consumer服务消费者

provide服务消费者，消费提供者提供的接口。 

这里没有过多代码，就是注入一个service，然后调用方法就可以了。配置和上面的类似。

1. 服务配置

```xml
    <!-- 提供方应用信息，用于计算依赖关系 -->
    <dubbo:application name="${dubbo.application.name}" />
    <!-- 注册中心暴露服务地址 -->
    <dubbo:registry protocol="${dubbo.registry.protocol}" address="${dubbo.registry.address}" />

    <dubbo:reference interface="com.hejia.api.service.UserService" id="userService" version="1.0.0" check="false"/>
```

2. 参数配置

```properties
#应用名称
dubbo.application.name=pisces-consumer
#注册中心类型
dubbo.registry.protocol=zookeeper
#注册中心地址
dubbo.registry.address=127.0.0.1:2181
```

## API接口层

api接口层，需要将API打包成jar包，在下面两个工程里定义。内部的dto，exception包是接口对外的数据模型和异常信息。

将接口层提取出来作为统一的接口层，方面在各个服务里接口不同服务。

至于dto层和exception层可以根据需求看看在各自服务里是否需要使用。



## 注册管理中心的安装

1. 安装Zookeeper

下载Zookeeper安装包，然后安装启动即可。默认的Zookeeper地址是：127.0.0.1 2181


2. 安装管理控制台

下载dubbo-opsx项目，然后编译放到tomcat下启动即可。可以在项目里编辑简单的dubbo配置

 **vi webapps/ROOT/WEB-INF/dubbo.properties**
```properties
 dubbo.registry.address=zookeeper://127.0.0.1:2181
#配置dubbo的默认账号密码
 dubbo.admin.root.password=root
 dubbo.admin.guest.password=guest
```

## 结束

上面就是dubbo的简单使用，如果有不清楚的可以去dubbo官网或给我留言，我会尽快回复你。

有兴趣的可以关注我的博客，我会不时更新相关文章。

我的博客：[http://www.shuihua.me/](http://www.shuihua.me/)
