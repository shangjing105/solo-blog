title: AngularJS路由的使用--ngRoute
date: '2016-04-28 13:44:03'
updated: '2016-04-28 13:44:03'
tags: [路由, angularjs]
permalink: /articles/2016/04/28/1461822220621.html
---
<h1 id="ngRoute"><code>ngRoute</code></h1>
<p>本篇文章我们将介绍如何使用AngularJS内置的<code>ngRoute</code>模块来做前端路由。</p>
<p>我不太记得AngularJS是从哪个版本开始将<code>ngRoute</code>独立成一个单独的module，貌似是1.2之后吧，现在如果要使用<code>ngRoute</code>需要额外加载这个模块文件，就像下面这样，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span></pre>
</td>
<td class="code">
<pre><span class="line"><span class="tag">&lt;<span class="title">script</span> <span class="attribute">src</span>=<span class="value">"../bower_components/angular/angular.js"</span>&gt;</span><span class="tag">&lt;/<span class="title">script</span>&gt;</span></span><br /><span class="line"><span class="tag">&lt;<span class="title">script</span> <span class="attribute">src</span>=<span class="value">"../bower_components/angular-route/angular-route.js"</span>&gt;</span><span class="tag">&lt;/<span class="title">script</span>&gt;</span></span></pre>
</td>
</tr>
</tbody>
</table>
<p>除了<span>angular-route</span>模块，还有<span>angular-animate</span>，<span>anglar-aria</span>，<span>angular-cookies</span>等模块在使用时也需要额外引入相关文件。这地方有点小坑，大家注意一下就可以了。</p>
<h2 id="使用说明">使用说明</h2>
<p><code>ngRoute</code>模块中包含以下内容，</p>
<table>
<thead>
<tr><th>名称</th><th>所属</th><th>作用</th></tr>
</thead>
<tbody>
<tr>
<td><code>ngView</code></td>
<td>DIRECTIVE</td>
<td>提供不同路由模板插入的视图层</td>
</tr>
<tr>
<td><code>$routeProvider</code></td>
<td>PROVIDER</td>
<td>提供路由配置</td>
</tr>
<tr>
<td><code>$route</code></td>
<td>SERVICE</td>
<td>用于构建各个路由的url、view、controller这三者的关系</td>
</tr>
<tr>
<td><code>$routeParams</code></td>
<td>SERVICE</td>
<td>解析返回路由中带有的参数</td>
</tr>
</tbody>
</table>
<p>上表中的每一个组件在路由中都扮演着不可或缺的作用。基本上使用AngularJS配置路由的基本流程是这样的，</p>
<ol>
<li>在主模板中使用<code>ngView</code>定义一个路由模板的视图层。不同路由对应的模板将会插入到这个<code>ngView</code>所在的dom元素下。</li>
<li>使用<code>$routeProvider</code>进行路由配置，包括每一个路由对应的url，template以及controller。除了这些基本的配置之外，还会有一些额外的配置，比如<code>resolve</code>配置等。</li>
<li>在每个路由的controller中完成对应的业务逻辑。</li>
<li>可以通过注入<code>$routeParams</code>服务来获取路由url上的参数；还可以通过<code>$rootScope</code>来监控<code>$routeChangeStart</code>和<code>$routeChangeSuccess</code>事件。</li>
</ol>
<h2 id="简单实例">简单实例</h2>
<p>在实例代码<a href="https://github.com/gejiawen/angular-route-demo" target="_blank" rel="external">仓库</a>中有一个<span>demo001</span>文件夹，其目录结构如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span></pre>
</td>
<td class="code">
<pre><span class="line">- index.html</span><br /><span class="line">- home.html</span><br /><span class="line">- post.html</span><br /><span class="line">- about.html</span><br /><span class="line">- index.js</span></pre>
</td>
</tr>
</tbody>
</table>
<p>其中<code>index.html</code>是我们的主页面文件，其内容如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span></pre>
</td>
<td class="code">
<pre><span class="line"><span class="tag">&lt;<span class="title">body</span> <span class="attribute">ng-app</span>=<span class="value">"demo001"</span> <span class="attribute">ng-controller</span>=<span class="value">"Demo"</span>&gt;</span></span><br /><span class="line">    <span class="tag">&lt;<span class="title">h1</span>&gt;</span>Angular Route Demo<span class="tag">&lt;/<span class="title">h1</span>&gt;</span></span><br /><span class="line">    <span class="tag">&lt;<span class="title">hr</span>&gt;</span></span><br /><span class="line">    <span class="tag">&lt;<span class="title">div</span>&gt;</span></span><br /><span class="line">        <span class="tag">&lt;<span class="title">a</span> <span class="attribute">href</span>=<span class="value">"#/home"</span>&gt;</span>home<span class="tag">&lt;/<span class="title">a</span>&gt;</span></span><br /><span class="line">        <span class="tag">&lt;<span class="title">a</span> <span class="attribute">href</span>=<span class="value">"#/post"</span>&gt;</span>post<span class="tag">&lt;/<span class="title">a</span>&gt;</span></span><br /><span class="line">        <span class="tag">&lt;<span class="title">a</span> <span class="attribute">href</span>=<span class="value">"#/about"</span>&gt;</span>about<span class="tag">&lt;/<span class="title">a</span>&gt;</span></span><br /><span class="line">    <span class="tag">&lt;/<span class="title">div</span>&gt;</span></span><br /><span class="line">    <span class="tag">&lt;<span class="title">hr</span>&gt;</span></span><br /><span class="line">    <span class="tag">&lt;<span class="title">div</span> <span class="attribute">ng-view</span>&gt;</span><span class="tag">&lt;/<span class="title">div</span>&gt;</span></span><br /><span class="line"><span class="tag">&lt;/<span class="title">body</span>&gt;</span></span></pre>
</td>
</tr>
</tbody>
</table>
<p>注意，我们的页面上有一个<code>ng-view</code>指令。</p>
<p>在<code>index.js</code>中，我们需要声明一个AngularJS的module叫做<em>demo001</em>，并且做一些路由配置工作。代码如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span><br /><span class="line">12</span><br /><span class="line">13</span><br /><span class="line">14</span><br /><span class="line">15</span><br /><span class="line">16</span><br /><span class="line">17</span><br /><span class="line">18</span><br /><span class="line">19</span><br /><span class="line">20</span></pre>
</td>
<td class="code">
<pre><span class="line">angular.module(<span class="string">'demo001'</span>, [<span class="string">'ngRoute'</span>])</span><br /><span class="line">.config([</span><br /><span class="line">    <span class="string">'$routeProvider'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$routeProvider</span>) </span>{</span><br /><span class="line">        $routeProvider</span><br /><span class="line">            .when(<span class="string">'/home'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'home.html'</span>,</span><br /><span class="line">                controller: <span class="string">'HomeController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .when(<span class="string">'/post'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'post.html'</span>,</span><br /><span class="line">                controller: <span class="string">'PostController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .when(<span class="string">'/about'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'about.html'</span>,</span><br /><span class="line">                controller: <span class="string">'AboutController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .otherwise(<span class="string">'/home'</span>)</span><br /><span class="line">    }</span><br /><span class="line">])</span></pre>
</td>
</tr>
</tbody>
</table>
<p>这里有3点需要注意，</p>
<ol>
<li>在声明<code>demo001</code>这个module的时候，需要将<code>ngRoute</code>作为依赖。否则报<code>$routeProvider</code>未定义这样的错误。</li>
<li>在module的configuration中，我们调用<code>$routeProvider.when</code>来配置不同路由的具体信息。<code>$routeProvider.when</code>方法接受2个参数，第一个是路由的url。第二个路由的具体配置，包括对应的模板地址，控制器名称等。</li>
<li><code>$routeProvider.otherwise</code>可以用于设置默认路由地址。简单来说就是将未设置的url自动重定向到此url。</li>
</ol>
<p>在我们补充完各个路由的控制器后，我们打开<code>index.html</code>就可以预览了。在预览时，注意点击不同链接时url的变化，还可以观察浏览器的Network行为。所有的子模板默认加载一次之后就会被缓存。</p>
<h2 id="模块化实例">模块化实例</h2>
<p>在经过上面的实例之后，应该对AngularJS路由的基本用法有所了解了。现在我们来假定有这样一个场景，假设我们的项目比较复杂，内部的模块很多。此时更优的一种方案是，基于AngularJS来做模块化设计与开发。AngularJS的模块化是以它的module以及依赖注入等行为作为基础的。</p>
<p>在实例代码<a href="https://github.com/gejiawen/angular-route-demo" target="_blank" rel="external">仓库</a>中有一个<span>demo002</span>的文件夹，其目录结构如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span></pre>
</td>
<td class="code">
<pre><span class="line">- index.html</span><br /><span class="line">- index.js</span><br /><span class="line">- home.html</span><br /><span class="line">- home.js</span><br /><span class="line">- post.html</span><br /><span class="line">- post-id.html</span><br /><span class="line">- post.js</span><br /><span class="line">- about.html</span><br /><span class="line">- about.js</span></pre>
</td>
</tr>
</tbody>
</table>
<p><code>index.html</code>与上一个实例相比基本没有变化。然后我们再看一眼<code>index.js</code>，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span><br /><span class="line">12</span><br /><span class="line">13</span></pre>
</td>
<td class="code">
<pre><span class="line">angular.module(<span class="string">'demo002'</span>, [</span><br /><span class="line">    <span class="string">'ngRoute'</span>,</span><br /><span class="line">    <span class="string">'Module.Home'</span>,</span><br /><span class="line">    <span class="string">'Module.Post'</span>,</span><br /><span class="line">    <span class="string">'Module.About'</span></span><br /><span class="line">])</span><br /><br /><span class="line">.config([</span><br /><span class="line">    <span class="string">'$routeProvider'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$routeProvider</span>) </span>{</span><br /><span class="line">        $routeProvider.otherwise(<span class="string">'/home'</span>);</span><br /><span class="line">    }</span><br /><span class="line">])</span></pre>
</td>
</tr>
</tbody>
</table>
<p>与之前不同的是，我们在声明<code>demo002</code>这个module时，附加了额外3个module。在路由的配置中，也仅仅只有一个<code>$routeProvider.otherwise</code>的设置。</p>
<p>这里我们就是使用了模块化的思想，将<code>/home</code>，<code>/post</code>，<code>/about</code>这几个路由抽象成独立的module，将他们内部的所有逻辑和设置都封装在内部。比如下面的<code>home.js</code></p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span><br /><span class="line">12</span><br /><span class="line">13</span><br /><span class="line">14</span><br /><span class="line">15</span><br /><span class="line">16</span><br /><span class="line">17</span><br /><span class="line">18</span></pre>
</td>
<td class="code">
<pre><span class="line">angular.module(<span class="string">'Module.Home'</span>, [<span class="string">'ngRoute'</span>])</span><br /><br /><span class="line">.config([</span><br /><span class="line">    <span class="string">'$routeProvider'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$routeProvider</span>) </span>{</span><br /><span class="line">        $routeProvider.when(<span class="string">'/home'</span>, {</span><br /><span class="line">            templateUrl: <span class="string">'home.html'</span>,</span><br /><span class="line">            controller: <span class="string">'HomeController'</span></span><br /><span class="line">        });</span><br /><span class="line">    }</span><br /><span class="line">])</span><br /><br /><span class="line">.controller(<span class="string">'HomeController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope</span>) </span>{</span><br /><span class="line">        $scope.msg = <span class="string">'This is home page'</span>;</span><br /><span class="line">    }</span><br /><span class="line">]);</span></pre>
</td>
</tr>
</tbody>
</table>
<p>AngularJS的module机制和依赖注入机制，为模块化设计提供了基础。在稍微复杂一点的angularjs项目中我是非常推荐使用模块化开发的，能够抽象成独立module的不仅仅是不同的路由模块，可以是一个公共组件，也可以是一个公共服务等等。</p>
<h2 id="路由参数">路由参数</h2>
<p>在上一个<span>模块化实例</span>中，我们的<code>post.js</code>模块如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span><br /><span class="line">12</span><br /><span class="line">13</span><br /><span class="line">14</span><br /><span class="line">15</span><br /><span class="line">16</span><br /><span class="line">17</span><br /><span class="line">18</span><br /><span class="line">19</span><br /><span class="line">20</span><br /><span class="line">21</span><br /><span class="line">22</span><br /><span class="line">23</span><br /><span class="line">24</span><br /><span class="line">25</span><br /><span class="line">26</span><br /><span class="line">27</span><br /><span class="line">28</span><br /><span class="line">29</span><br /><span class="line">30</span><br /><span class="line">31</span><br /><span class="line">32</span><br /><span class="line">33</span><br /><span class="line">34</span><br /><span class="line">35</span><br /><span class="line">36</span><br /><span class="line">37</span><br /><span class="line">38</span><br /><span class="line">39</span></pre>
</td>
<td class="code">
<pre><span class="line">angular.module(<span class="string">'Module.Post'</span>, [<span class="string">'ngRoute'</span>])</span><br /><br /><span class="line">.config([</span><br /><span class="line">    <span class="string">'$routeProvider'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$routerProvider</span>) </span>{</span><br /><span class="line">        $routerProvider</span><br /><span class="line">            .when(<span class="string">'/post'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'post.html'</span>,</span><br /><span class="line">                controller: <span class="string">'PostController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .when(<span class="string">'/post/:postId'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'post-id.html'</span>,</span><br /><span class="line">                controller: <span class="string">'PostIdController'</span></span><br /><span class="line">            })</span><br /><span class="line">    }</span><br /><span class="line">])</span><br /><br /><span class="line">.controller(<span class="string">'PostController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope</span>) </span>{</span><br /><span class="line">        $scope.posts = [</span><br /><span class="line">            {</span><br /><span class="line">                name: <span class="string">'post1'</span>,</span><br /><span class="line">                id: <span class="string">'post-001'</span></span><br /><span class="line">            }, {</span><br /><span class="line">                name: <span class="string">'post2'</span>,</span><br /><span class="line">                id: <span class="string">'post-002'</span></span><br /><span class="line">            }</span><br /><span class="line">        ]</span><br /><span class="line">    }</span><br /><span class="line">])</span><br /><br /><span class="line">.controller(<span class="string">'PostIdController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="string">'$routeParams'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope, $routeParams</span>) </span>{</span><br /><span class="line">        $scope.msg = <span class="string">'post id: '</span> + $routeParams.postId;</span><br /><span class="line">    }</span><br /><span class="line">]);</span></pre>
</td>
</tr>
</tbody>
</table>
<p>注意这里，我们使用<code>$routeProvider</code>配置的第二个路由是这样的<code>/post/:postId</code>。路由中的<code>/:postId</code>其实是一个参数，它将匹配类似<code>/post/001</code>这种url，其中<span>001</span>就是这个<code>:postId</code>的值。</p>
<p>我们在路由对应的控制器中，可以通过<code>$routeParams</code>参数来获取这个url参数。如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span></pre>
</td>
<td class="code">
<pre><span class="line">.controller(<span class="string">'PostIdController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="string">'$routeParams'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope, $routeParams</span>) </span>{</span><br /><span class="line">        $scope.msg = <span class="string">'post id: '</span> + $routeParams.postId;</span><br /><span class="line">    }</span><br /><span class="line">]);</span></pre>
</td>
</tr>
</tbody>
</table>
<p>依次类推，我们可以为路由的url设置多个参数，比如<code>/post/:year/:month/:day/:postName</code>这样的路由，它将匹配<em>/post/2015/12/15/angular-router-demo</em>这样的路径。控制器中注入的<code>$routeParams</code>服务将会得到类似下面的对象，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span></pre>
</td>
<td class="code">
<pre><span class="line">{</span><br /><span class="line">    <span class="string">"year"</span>: <span class="number">2015</span>,</span><br /><span class="line">    <span class="string">"month"</span>: <span class="number">12</span>,</span><br /><span class="line">    <span class="string">"day"</span>: <span class="number">15</span>,</span><br /><span class="line">    <span class="string">"postName"</span>: <span class="string">"angular-router-demo"</span></span><br /><span class="line">}</span></pre>
</td>
</tr>
</tbody>
</table>
<h2 id="路由中的resolve">路由中的resolve</h2>
<p>在前面我们已经说明，可以使用<code>$routeProvider.when</code>方法进行路由配置。这个<code>$routeProvider.when</code>方法接受2个参数，其中第一个是路由的url，第二个是路由的具体配置项目。</p>
<p>关于<a href="https://docs.angularjs.org/api/ngRoute/provider/$routeProvider#when" target="_blank" rel="external">$routeProvider.when</a>的具体用法可以参考官方的文档。</p>
<p>这里我仅仅针对其中的一个配置项<code>resolve</code>进行一些说明。</p>
<p>我们先来假设一个场景。</p>
<p>比如我最近上班太累了，想来一场旅行。在旅行之前，我需要拿到一张机票。而旅游网站出票是需要时间的。</p>
<p>将这个场景抽象成AngularJS应用就是这样的：</p>
<ol>
<li>有两个页面，一个是上班页面（<code>/home</code>），一个是拿到机票开始旅行页面（<code>/trip</code>）。</li>
<li>默认处于上班页面。可以通过导航到开始旅行页面。</li>
<li>在进入旅行页面之前，我们必须要有一张机票。</li>
</ol>
<p>所以，这个场景中，我们的问题可以总结成，当我从<code>/home</code>进入<code>/trip</code>路由之前，必须要拿到一个机票数据。</p>
<p>在实例代码<a href="https://github.com/gejiawen/angular-route-demo" target="_blank" rel="external">仓库</a>中有一个<span>demo003</span>文件夹，其目录结构如下，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span></pre>
</td>
<td class="code">
<pre><span class="line">- index.html</span><br /><span class="line">- index.js</span><br /><span class="line">- index2.js <span class="comment">// resolve方案</span></span><br /><span class="line">- home.html</span><br /><span class="line">- trip.html</span></pre>
</td>
</tr>
</tbody>
</table>
<p>在<code>index.js</code>中，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span><br /><span class="line">12</span><br /><span class="line">13</span><br /><span class="line">14</span><br /><span class="line">15</span><br /><span class="line">16</span><br /><span class="line">17</span><br /><span class="line">18</span><br /><span class="line">19</span><br /><span class="line">20</span><br /><span class="line">21</span><br /><span class="line">22</span><br /><span class="line">23</span><br /><span class="line">24</span><br /><span class="line">25</span></pre>
</td>
<td class="code">
<pre><span class="line">.config([</span><br /><span class="line">    <span class="string">'$routeProvider'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$routeProvider</span>) </span>{</span><br /><span class="line">        $routeProvider</span><br /><span class="line">            .when(<span class="string">'/home'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'home.html'</span>,</span><br /><span class="line">                controller: <span class="string">'HomeController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .when(<span class="string">'/trip'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'trip.html'</span>,</span><br /><span class="line">                controller: <span class="string">'TripController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .otherwise(<span class="string">'/home'</span>);</span><br /><span class="line">    }</span><br /><span class="line">])</span><br /><br /><span class="line">.controller(<span class="string">'TripController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="string">'$timeout'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope, $timeout</span>) </span>{</span><br /><span class="line">        $timeout(<span class="function"><span class="keyword">function</span> () </span>{</span><br /><span class="line">            $scope.ticket = <span class="string">'上海 -&gt; 澳大利亚'</span></span><br /><span class="line">        }, <span class="number">4000</span>);</span><br /><span class="line">    }</span><br /><span class="line">])</span></pre>
</td>
</tr>
</tbody>
</table>
<p>这里我们使用定时器<code>$timeout</code>来模拟一个耗时的出票操作。此时我们从<code>/home</code>-&gt;<code>/trip</code>时，页面会白屏4秒钟。意味着在进行url跳转完毕的时候，我们就已经将<code>/trip</code>的模板插入到了<code>ng-view</code>中，但是此时<code>/trip</code>需要的数据还没有准备好。</p>
<p>这种场景下，我们一般会有两种方式去解决这个问题，</p>
<ol>
<li>第一种方式：在<code>/trip</code>的模板和控制器中做一些视觉等待逻辑。比如在<code>TripController</code>中进行耗时操作时，我们可以临时展示一个loading视觉，待耗时操作完毕之后，我们再将这个视觉隐藏即可。</li>
<li>第二种方式：在配置路由时，配置<code>resolve</code>选项。配置<code>resolve</code>选项意味着，在进入这个路由之前就必须等待<code>resolve</code>中的数据返回。</li>
</ol>
<p>这里我们主要来看看第二种方式。在实例代码仓库的<span>demo003</span>文件夹下的<code>index2.js</code>中，我们是怎么做的，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span><br /><span class="line">8</span><br /><span class="line">9</span><br /><span class="line">10</span><br /><span class="line">11</span><br /><span class="line">12</span><br /><span class="line">13</span><br /><span class="line">14</span><br /><span class="line">15</span><br /><span class="line">16</span><br /><span class="line">17</span><br /><span class="line">18</span><br /><span class="line">19</span><br /><span class="line">20</span><br /><span class="line">21</span><br /><span class="line">22</span><br /><span class="line">23</span><br /><span class="line">24</span><br /><span class="line">25</span><br /><span class="line">26</span><br /><span class="line">27</span><br /><span class="line">28</span><br /><span class="line">29</span><br /><span class="line">30</span><br /><span class="line">31</span><br /><span class="line">32</span></pre>
</td>
<td class="code">
<pre><span class="line">.config([</span><br /><span class="line">    <span class="string">'$routeProvider'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$routeProvider</span>) </span>{</span><br /><span class="line">        $routeProvider</span><br /><span class="line">            .when(<span class="string">'/home'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'home.html'</span>,</span><br /><span class="line">                controller: <span class="string">'HomeController'</span></span><br /><span class="line">            })</span><br /><span class="line">            .when(<span class="string">'/trip'</span>, {</span><br /><span class="line">                templateUrl: <span class="string">'trip.html'</span>,</span><br /><span class="line">                controller: <span class="string">'TripController'</span>,</span><br /><span class="line">                resolve: {</span><br /><span class="line">                    ticket: [<span class="string">'$q'</span>, <span class="string">'$timeout'</span>, <span class="function"><span class="keyword">function</span> (<span class="params">$q, $timeout</span>) </span>{</span><br /><span class="line">                        <span class="keyword">var</span> deferred = $q.defer();</span><br /><span class="line">                        $timeout(<span class="function"><span class="keyword">function</span> () </span>{</span><br /><span class="line">                            deferred.resolve(<span class="string">'上海 -&gt; 澳大利亚'</span>);</span><br /><span class="line">                        }, <span class="number">4000</span>);</span><br /><span class="line">                        <span class="keyword">return</span> deferred.promise;</span><br /><span class="line">                    }]</span><br /><span class="line">                }</span><br /><span class="line">            })</span><br /><span class="line">            .otherwise(<span class="string">'/home'</span>);</span><br /><span class="line">    }</span><br /><span class="line">])</span><br /><br /><span class="line">.controller(<span class="string">'TripController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="string">'ticket'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope, ticket</span>) </span>{</span><br /><span class="line">        $scope.ticket = ticket;</span><br /><span class="line">    }</span><br /><span class="line">])</span></pre>
</td>
</tr>
</tbody>
</table>
<p>注意<code>/trip</code>路由的配置中，我们设置了一个<code>resolve</code>配置项。这个配置项包含了一个叫做<code>ticket</code>的key，它将返回一个promise（这里采用AngularJS内置的<a href="https://docs.angularjs.org/api/ng/service/$q" target="_blank" rel="external">$q</a>来实现promise）。其内部也是使用定时器做了一个耗时操作的模拟。</p>
<p>当我们的路由从<code>/home</code>-&gt;<code>/trip</code>时，会触发<code>resolve</code>下的所有promise，只有当所有的promise都都被正确的resolve之后才会进行路由切换，才会将<code>/trip</code>的模板插入到<code>ng-view</code>中。其实此时<code>$route</code>会抛出一个<code>$routeChangeSuccess</code>的事件，这个事件会被<code>$rootScope</code>捕获到。</p>
<p>若<code>resolve</code>中只要有一个promise没有被正确的resolve，那么此时<code>$route</code>将会抛出一个<code>$routeChangeError</code>的事件，并且终止路由切换，虽然url中的地址可能的确发生了变化，但是<code>/trip</code>的模板并没有插入到<code>ng-view</code>，且<code>TripController</code>也没有被执行。</p>
<p>当所有的<code>resolve</code>配置都返回之后，AngularJS会将<code>resolve</code>中key作为对应控制器的一个依赖注入进去，然后我们在相应的controller中就可以使用了。比如，</p>
<table>
<tbody>
<tr>
<td class="gutter">
<pre><span class="line">1</span><br /><span class="line">2</span><br /><span class="line">3</span><br /><span class="line">4</span><br /><span class="line">5</span><br /><span class="line">6</span><br /><span class="line">7</span></pre>
</td>
<td class="code">
<pre><span class="line">.controller(<span class="string">'TripController'</span>, [</span><br /><span class="line">    <span class="string">'$scope'</span>,</span><br /><span class="line">    <span class="string">'ticket'</span>,</span><br /><span class="line">    <span class="function"><span class="keyword">function</span> (<span class="params">$scope, ticket</span>) </span>{</span><br /><span class="line">        $scope.ticket = ticket;</span><br /><span class="line">    }</span><br /><span class="line">])</span></pre>
</td>
</tr>
</tbody>
</table>
<p>这里可以看出，上面提到的两种<span>预载入数据</span>的方案其实是有着本质区别的。前者其实是在跳转的目标路由上做一些额外的工作去适配耗时操作的视觉，此时目标路由的模板已经被载入<code>ng-view</code>，且相应的控制器也被执行了。而后者在跳转目标路由之前做一些额外工作去预加载数据，当数据准备妥当才会去载入目标路由的模板和执行相应的controller。</p>