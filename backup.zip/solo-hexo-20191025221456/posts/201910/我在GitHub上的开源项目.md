title: 我在 GitHub 上的开源项目
date: '2019-10-16 22:04:58'
updated: '2019-10-16 22:04:58'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [spray-module](https://github.com/shangjing105/spray-module) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/shangjing105/spray-module/watchers "关注数")&nbsp;&nbsp;[⭐️`21`](https://github.com/shangjing105/spray-module/stargazers "收藏数")&nbsp;&nbsp;[🖖`14`](https://github.com/shangjing105/spray-module/network/members "分叉数")</span>

spray模块架构分离



---

### 2. [spray-web](https://github.com/shangjing105/spray-web) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/shangjing105/spray-web/watchers "关注数")&nbsp;&nbsp;[⭐️`12`](https://github.com/shangjing105/spray-web/stargazers "收藏数")&nbsp;&nbsp;[🖖`7`](https://github.com/shangjing105/spray-web/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.pgyer.com/0qj6`](https://www.pgyer.com/0qj6 "项目主页")</span>

水花一现-ionic前端



---

### 3. [spray-photo](https://github.com/shangjing105/spray-photo) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/shangjing105/spray-photo/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/shangjing105/spray-photo/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/shangjing105/spray-photo/network/members "分叉数")&nbsp;&nbsp;[🏠`http://photo.shangshun.me/`](http://photo.shangshun.me/ "项目主页")</span>

照片之家



---

### 4. [spray-manage](https://github.com/shangjing105/spray-manage) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/shangjing105/spray-manage/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/shangjing105/spray-manage/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/shangjing105/spray-manage/network/members "分叉数")</span>

springboot后台架构



---

### 5. [solo-blog](https://github.com/shangjing105/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/shangjing105/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/shangjing105/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/shangjing105/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`http://www.shuihua.me`](http://www.shuihua.me "项目主页")</span>

水花一现 - 走自己的路



---

### 6. [spray-mvc](https://github.com/shangjing105/spray-mvc) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/shangjing105/spray-mvc/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/shangjing105/spray-mvc/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/shangjing105/spray-mvc/network/members "分叉数")</span>

springmvc架构



---

### 7. [atest](https://github.com/shangjing105/atest) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/shangjing105/atest/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/shangjing105/atest/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/shangjing105/atest/network/members "分叉数")</span>

angularjs练手小项目



---

### 8. [ntest](https://github.com/shangjing105/ntest) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/shangjing105/ntest/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/shangjing105/ntest/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/shangjing105/ntest/network/members "分叉数")</span>

nodejs练手项目

