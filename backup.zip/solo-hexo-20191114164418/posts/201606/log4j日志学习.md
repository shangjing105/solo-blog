title: log4j日志学习
date: '2016-06-13 17:06:31'
updated: '2016-06-13 17:06:31'
tags: [log4j, java]
permalink: /articles/2016/06/13/1465808754867.html
---
### log4j介绍

`日志是应用软件中不可缺少的部分，Apache的开源项目log4j是一个功能强大的日志组件,提供方便的日志记录。`

在apache网站：[jakarta.apache.org](http://jakarta.apache.org) 可以免费下载到Log4j最新版本的软件包

----

### log4j详解

**1.输出级别的种类**

	ERROR、WARN、INFO、DEBUG
	ERROR 为严重错误 主要是程序的错误
	WARN 为一般警告，比如session丢失
	INFO 为一般要显示的信息，比如登录登出
	DEBUG 为程序的调试信息
	
**2.配置日志信息输出目的地**

	log4j.appender.appenderName = fully.qualified.name.of.appender.class
	1.org.apache.log4j.ConsoleAppender（控制台）
	2.org.apache.log4j.FileAppender（文件）
	3.org.apache.log4j.DailyRollingFileAppender（每天产生一个日志文件）
	4.org.apache.log4j.RollingFileAppender（文件大小到达指定尺寸的时候产生一个新的文件）
	5.org.apache.log4j.WriterAppender（将日志信息以流格式发送到任意指定的地方）
	
**3.配置日志信息的格式**

	log4j.appender.appenderName.layout = fully.qualified.name.of.layout.class
	1.org.apache.log4j.HTMLLayout（以HTML表格形式布局），
	2.org.apache.log4j.PatternLayout（可以灵活地指定布局模式），
	3.org.apache.log4j.SimpleLayout（包含日志信息的级别和信息字符串），
	4.org.apache.log4j.TTCCLayout（包含日志产生的时间、线程、类别等等信息）
	
**4.控制台选项**

	Threshold=DEBUG:指定日志消息的输出最低层次。
	ImmediateFlush=true:默认值是true,意谓着所有的消息都会被立即输出。
	Target=System.err：默认情况下是：System.out,指定输出控制台
	FileAppender 选项
	Threshold=DEBUF:指定日志消息的输出最低层次。
	ImmediateFlush=true:默认值是true,意谓着所有的消息都会被立即输出。
	File=mylog.txt:指定消息输出到mylog.txt文件。
	Append=false:默认值是true,即将消息增加到指定文件中，false指将消息覆盖指定的文件内容。
	RollingFileAppender 选项
	Threshold=DEBUG:指定日志消息的输出最低层次。
	ImmediateFlush=true:默认值是true,意谓着所有的消息都会被立即输出。
	File=mylog.txt:指定消息输出到mylog.txt文件。
	Append=false:默认值是true,即将消息增加到指定文件中，false指将消息覆盖指定的文件内容。
	MaxFileSize=100KB: 后缀可以是KB, MB 或者是 GB. 在日志文件到达该大小时，将会自动滚动，即将原来的内容移到mylog.log.1文件。
	MaxBackupIndex=2:指定可以产生的滚动文件的最大数。
	log4j.appender.A1.layout.ConversionPattern=%-4r %-5p %d{yyyy-MM-dd HH:mm:ssS} %c %m%n
	
**5.日志信息格式中几个符号所代表的含义：**

	-X号: X信息输出时左对齐；
	 %p: 输出日志信息优先级，即DEBUG，INFO，WARN，ERROR，FATAL,
	 %d: 输出日志时间点的日期或时间，默认格式为ISO8601，也可以在其后指定格式，比如：%d{yyy MMM dd HH:mm:ss,SSS}，输出类似：2002年10月18日 22：10：28，921
	 %r: 输出自应用启动到输出该log信息耗费的毫秒数
	 %c: 输出日志信息所属的类目，通常就是所在类的全名
	 %t: 输出产生该日志事件的线程名
	 %l: 输出日志事件的发生位置，相当于%C.%M(%F:%L)的组合,包括类目名、发生的线程，以及在代码中的行数。举例：Testlog4.main (TestLog4.java:10)
	 %x: 输出和当前线程相关联的NDC(嵌套诊断环境),尤其用到像java servlets这样的多客户多线程的应用中。
	 %%: 输出一个"%"字符
	 %F: 输出日志消息产生时所在的文件名称
	 %L: 输出代码中的行号
	 %m: 输出代码中指定的消息,产生的日志具体信息
	 %n: 输出一个回车换行符，Windows平台为"/r/n"，Unix平台为"/n"输出日志信息换行
	 
	

### log4j使用

<pre><code>
###日志显示级别
log4j.rootLogger=INFO,stdout,sysLogFile
log4j.logger.com.spary=debug,stdout,sysLogFile
###控制台日志打印
log4j.appender.stdout=org.apache.log4j.ConsoleAppender
log4j.appender.stdout.encoding=UTF-8
log4j.appender.stdout.layout=org.apache.log4j.PatternLayout
log4j.appender.stdout.layout.ConversionPattern=%-d{yyyy-MM-dd HH\:mm\:ss} %l-[%p] %m -(\:%L)%n
###info日志保存在log文件里
log4j.appender.sysLogFile=org.apache.log4j.RollingFileAppender
log4j.appender.sysLogFile.encoding=UTF-8
log4j.appender.sysLogFile.File=../logs/spary/spary.info.log
log4j.appender.sysLogFile.MaxFileSize= 10000KB
log4j.appender.sysLogFile.MaxBackupIndex=100
log4j.appender.sysLogFile.Threshold = INFO
log4j.appender.sysLogFile.layout=org.apache.log4j.PatternLayout
log4j.appender.sysLogFile.layout.ConversionPattern=%-d{yyyy-MM-dd HH\:mm\:ss} %l-[%p] %m -(\:%L)%n
</code></pre>

---
