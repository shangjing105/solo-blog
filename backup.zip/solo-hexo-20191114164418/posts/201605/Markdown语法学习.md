title: Markdown语法学习
date: '2016-05-25 17:51:28'
updated: '2016-05-25 17:52:41'
tags: [Markdown]
permalink: /articles/2016/05/25/1464169829800.html
---
## 百科定义  

> Markdown是一种可以使用普通文本编辑器编写的标记语言，通过简单的标记语法，它可以使普通文本内容具有一定的格式。
Markdown具有一系列衍生版本，用于扩展Markdown的功能（如表格、脚注、内嵌HTML等等），这些功能原初的Markdown尚不具备，它们能让Markdown转换成更多的格式，例如LaTeX，Docbook。Markdown增强版中比较有名的有Markdown Extra、MultiMarkdown、 Maruku等。这些衍生版本要么基于工具，如Pandoc；要么基于网站，如GitHub和Wikipedia，在语法上基本兼容，但在一些语法和渲染效果上有改动。 

***  


## 学习效果图  

![效果图](http://o6n64wdk9.bkt.clouddn.com/3432554e821e4cdea552a008d30b6cd4.png)  

***  

## Markdown中文学习手册地址  

<http://www.appinn.com/markdown/index.html>  
其他学习地址：  
<http://sspai.com/25137>