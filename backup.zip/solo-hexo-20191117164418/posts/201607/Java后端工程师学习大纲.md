title: Java后端工程师学习大纲
date: '2016-07-07 16:22:07'
updated: '2016-07-11 18:01:40'
tags: [java]
permalink: /articles/2016/07/07/1467879570050.html
---
<p class="p1"><span class="s1">之前自己总结过的<a href="http://www.rowkey.me/blog/2016/06/17/java-skill-tree/"><span class="s2">Java后端工程师技能树</span></a>，其涵盖的技术点比较全面，并非一朝一夕能够全部覆盖到的。对于一些还没有入门或者刚刚入门的Java后端工程师，如果一下子需要学习如此多的知识，想必很多人会望而却步。</span></p>
<p class="p1"><span class="s1">本文截取了技能树中的一些关键技能点，并辅以学习资料和书籍推荐，做为Java后端工程师的一个入门或者入职学习计划，是一个相对完整的从基础到高级的修炼过程。基本上涵盖了一个合格的Java后端工程师必备的技能点。</span></p>
<p class="p2"><span class="s1"><strong>本大纲会持续更新</strong></span><span class="s3">^_^&hellip;</span></p>
<p class="p3"><span class="s1"><strong>一. Git版本管理+Maven工程管理</strong></span></p>
<p class="p4"><span class="s1"><a href="http://weibo.com/p/1001643874239169320051">微博新兵训练营课程&mdash;&mdash;环境与工具</a></span></p>
<p class="p3"><span class="s1"><strong>二. Java编程</strong></span></p>
<p class="p3"><span class="s1"><strong>书籍</strong></span></p>
<ul class="ul1">
<li class="li1"><span class="s4"><a href="https://book.douban.com/subject/3146174/"><span class="s5">《Java核心技术(卷1)》</span></a></span><span class="s1">：学习java必备的黄皮书，入门推荐书籍</span></li>
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/3360866/"><span class="s5">《Java核心技术(卷2)》</span></a></span><span class="s7">：黄皮书之高级特性</span></li>
<li class="li1"><span class="s4"><a href="https://book.douban.com/subject/10484692/"><span class="s5">《Java并发编程实战》</span></a></span><span class="s1">: 对java并发库讲得非常透彻</span></li>
<li class="li1"><span class="s4"><a href="https://book.douban.com/subject/3360807/"><span class="s5">《Effective Java》</span></a></span><span class="s1">：Java之父高司令都称赞的一本java进阶书籍</span></li>
<li class="li1"><span class="s4"><a href="https://book.douban.com/subject/26274206/"><span class="s5">《写给大忙人看的Java SE 8》</span></a></span><span class="s1">:涵盖了java8带来以及java7中被略过的新的java特性，值得一看</span></li>
</ul>
<p class="p3"><span class="s1"><strong>资料</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s7">Socket编程: <a href="http://ifeve.com/java-socket/"><span class="s2">http://ifeve.com/java-socket/</span></a></span></li>
<li class="li4"><span class="s7">NIO: <a href="http://ifeve.com/java-nio-all/"><span class="s2">http://ifeve.com/java-nio-all/</span></a></span></li>
<li class="li4"><span class="s7">序列化: <a href="http://ifeve.com/java-io-s-objectinputstream-objectoutputstream/"><span class="s2">http://ifeve.com/java-io-s-objectinputstream-objectoutputstream/</span></a></span></li>
<li class="li4"><span class="s7">RPC框架: <a href="http://dubbo.io/"><span class="s2">http://dubbo.io</span></a></span></li>
<li class="li4"><span class="s7">并发编程：<a href="http://ifeve.com/java-concurrency-constructs/"><span class="s2">http://ifeve.com/java-concurrency-constructs/</span></a></span></li>
</ul>
<p class="p3"><span class="s1"><strong>三. 开发框架</strong></span></p>
<ul class="ul1">
<li class="li1"><span class="s1">Spring: <a href="http://www.open-open.com/doc/view/5407635b943d410c9cfde409c90450b7"><span class="s2">跟开涛学Spring3</span></a></span></li>
<li class="li1"><span class="s1">Spring MVC: <a href="http://www.cnblogs.com/kaitao/archive/2012/07/16/2593441.html"><span class="s2">跟开涛学SpringMvc</span></a></span></li>
<li class="li4"><span class="s7">MyBatis: <a href="http://www.yihaomen.com/article/java/302.htm"><span class="s2">MyBatis实战教程</span></a><a href="http://limingnihao.iteye.com/blog/781671"><span class="s2">MyBatis学习</span></a></span></li>
</ul>
<p class="p1"><span class="s1">对于这些框架或者是一些常用的软件，个人最推崇的还是阅读</span><span class="s9"><strong>官方文档</strong></span><span class="s1">来学习。当然，看这些资料能让你入门地更加快速一些。</span></p>
<p class="p1"><span class="s1">更进一步的，在学会使用之后，去阅读这些框架或软件的源码是必不可少的一步。阅读源码的一种比较好的步骤如下：</span></p>
<ul class="ul1">
<li class="li1"><span class="s1">1) 先阅读架构文档</span></li>
<li class="li1"><span class="s1">2) 根据架构，将源码文件以模块（或上下层级）分类</span></li>
<li class="li1"><span class="s1">3) 从最独立（依赖性最小）的模块代码读起</span></li>
<li class="li1"><span class="s1">4) 阅读该模块功能文档</span></li>
<li class="li1"><span class="s1">5) 阅读该模块源代码</span></li>
<li class="li1"><span class="s1">6) 一边阅读一边整理「调用关系表」</span></li>
<li class="li1"><span class="s1">7) goto 3</span></li>
</ul>
<p class="p3"><span class="s1"><strong>四. 性能优化与诊断-系统</strong></span></p>
<p class="p4"><span class="s1"><a href="https://book.douban.com/subject/4027746/">《Linux服务器性能调整》</a></span></p>
<p class="p1"><span class="s1">学习内容：</span></p>
<ul class="ul1">
<li class="li1"><span class="s1">Linux概述</span></li>
<li class="li1"><span class="s1">性能分析工具</span></li>
<li class="li1"><span class="s1">系统调优</span></li>
<li class="li1"><span class="s1">Linux服务器应用的性能特征</span></li>
<li class="li1"><span class="s1">调优案例分析</span></li>
</ul>
<p class="p3"><span class="s1"><strong>五. 性能优化与诊断-JVM</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/25828043/"><span class="s5">《Java性能优化权威指南》</span></a></span><span class="s7"><br /> 学习内容：</span></li>
<ul class="ul2">
<li class="li1"><span class="s1">JVM概述</span></li>
<li class="li1"><span class="s1">JVM性能监控</span></li>
<li class="li1"><span class="s1">JVM性能剖析与工具</span></li>
<li class="li1"><span class="s1">JVM参数与调优步骤</span></li>
<li class="li1"><span class="s1">JVM调优案例分析</span></li>
</ul>
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/24722612/"><span class="s5">《深入理解Java虚拟机(第二版)》</span></a></span></li>
</ul>
<p class="p3"><span class="s1"><strong>六. 消息中间件</strong></span></p>
<p class="p3"><span class="s1"><strong>JMS</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s7">大规模分布式消息中间件简介：<a href="http://blog.csdn.net/huyiyang2010/article/details/5969944"><span class="s2">http://blog.csdn.net/huyiyang2010/article/details/5969944</span></a></span></li>
<li class="li4"><span class="s7">JMS Overview: <a href="http://docs.oracle.com/javaee/6/tutorial/doc/bncdr.html"><span class="s2">http://docs.oracle.com/javaee/6/tutorial/doc/bncdr.html</span></a></span></li>
<li class="li4"><span class="s7">Basic JMS API Concepts: <a href="http://docs.oracle.com/javaee/6/tutorial/doc/bncdx.html"><span class="s2">http://docs.oracle.com/javaee/6/tutorial/doc/bncdx.html</span></a></span></li>
<li class="li4"><span class="s7">The JMS API Programming Model: <a href="http://docs.oracle.com/javaee/6/tutorial/doc/bnceh.html"><span class="s2">http://docs.oracle.com/javaee/6/tutorial/doc/bnceh.html</span></a></span></li>
<li class="li4"><span class="s7">Creating Robust JMS Applications:<a href="http://docs.oracle.com/javaee/6/tutorial/doc/bncfu.html"><span class="s2">http://docs.oracle.com/javaee/6/tutorial/doc/bncfu.html</span></a></span></li>
<li class="li4"><span class="s7">Using the JMS API in Java EE Applications: <a href="http://docs.oracle.com/javaee/6/tutorial/doc/bncgl.html"><span class="s2">http://docs.oracle.com/javaee/6/tutorial/doc/bncgl.html</span></a></span></li>
<li class="li4"><span class="s7">Further Information about JMS: <a href="http://docs.oracle.com/javaee/6/tutorial/doc/bncgu.html"><span class="s2">http://docs.oracle.com/javaee/6/tutorial/doc/bncgu.html</span></a></span></li>
</ul>
<p class="p3"><span class="s1"><strong>Kafka</strong></span></p>
<p class="p4"><span class="s1"><a href="http://www.orchome.com/kafka/index">http://www.orchome.com/kafka/index</a></span></p>
<p class="p1"><span class="s1">学习内容：</span></p>
<ul class="ul1">
<li class="li1"><span class="s1">开始学习kafka</span></li>
<li class="li1"><span class="s1">入门</span></li>
<li class="li1"><span class="s1">接口</span></li>
<li class="li1"><span class="s1">配置</span></li>
<li class="li1"><span class="s1">设计</span></li>
<li class="li1"><span class="s1">实现</span></li>
<li class="li1"><span class="s1">什么是kafka</span></li>
<li class="li1"><span class="s1">什么场景下使用kafka</span></li>
</ul>
<p class="p3"><span class="s1"><strong>RabbitMQ</strong></span></p>
<p class="p4"><span class="s1"><a href="http://www.rabbitmq.com/documentation.html">官方文档</a></span></p>
<p class="p3"><span class="s1"><strong>七. Redis设计与实现</strong></span></p>
<p class="p4"><span class="s1"><a href="http://redisbook.com/">http://redisbook.com/</a></span></p>
<p class="p1"><span class="s1">学习内容：</span></p>
<ul class="ul1">
<li class="li1"><span class="s1">常用命令以及数据结构</span></li>
<li class="li1"><span class="s1">内部数据结构</span></li>
<li class="li1"><span class="s1">内存映射数据库结构</span></li>
<li class="li1"><span class="s1">redis数据类型</span></li>
<li class="li1"><span class="s1">功能的实现</span></li>
<li class="li1"><span class="s1">内部运作机制</span></li>
</ul>
<p class="p3"><span class="s1"><strong>八. 数据相关</strong></span></p>
<p class="p3"><span class="s1"><strong>理论基础</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s7">MapReduce：<a href="http://blog.csdn.net/active1001/archive/2007/07/02/1675920.aspx"><span class="s2">http://blog.csdn.net/active1001/archive/2007/07/02/1675920.aspx</span></a></span></li>
<li class="li4"><span class="s7">GFS：<a href="http://blog.csdn.net/xuleicsu/archive/2005/11/10/526386.aspx"><span class="s2">http://blog.csdn.net/xuleicsu/archive/2005/11/10/526386.aspx</span></a></span></li>
<li class="li4"><span class="s7">Bigtable：<a href="http://blog.csdn.net/accesine960/archive/2006/02/09/595628.aspx"><span class="s2">http://blog.csdn.net/accesine960/archive/2006/02/09/595628.aspx</span></a></span></li>
</ul>
<p class="p3"><span class="s1"><strong>实时计算</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s7">Storm:<a href="https://book.douban.com/subject/26312249/"><span class="s2">《Storm分布式实时计算模式》</span></a></span></li>
<li class="li1"><span class="s1">Spark streaming: <a href="https://spark.apache.org/streaming/"><span class="s2">官网文档</span></a></span></li>
</ul>
<p class="p3"><span class="s1"><strong>离线计算</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s7">Hadoop:<a href="https://book.douban.com/subject/26206050/"><span class="s2">《Hadoop权威指南》</span></a></span></li>
<li class="li4"><span class="s7">Hive:<a href="https://book.douban.com/subject/25791255/"><span class="s2">《Hive编程指南》</span></a></span></li>
<li class="li4"><span class="s7">Spark:<a href="https://book.douban.com/subject/26616244/"><span class="s2">《Spark快速大数据分析》</span></a></span></li>
</ul>
<p class="p3"><span class="s1"><strong>Lambda架构</strong></span></p>
<p class="p4"><span class="s1"><a href="http://www.csdn.net/article/2014-07-08/2820562-Lambda-Linkedln">Linkedln技术高管Jay Kreps：Lambda架构剖析</a></span></p>
<p class="p3"><span class="s1"><strong>机器学习：</strong></span></p>
<ul class="ul1">
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/10769749/"><span class="s5">《推荐系统实践》</span></a></span></li>
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/26596778/"><span class="s5">《计算广告》</span></a></span></li>
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/3288908/"><span class="s5">《集体智慧》</span></a></span></li>
<li class="li4"><span class="s6"><a href="https://book.douban.com/subject/26708119/"><span class="s5">《机器学习》</span></a></span></li>
</ul>
<p>&nbsp;</p>
<p>原文链接</p>
<p><a href="http://www.rowkey.me/blog/2016/06/27/java-backend-study/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io" target="_blank">http://www.rowkey.me/blog/2016/06/27/java-backend-study/?hmsr=toutiao.io&amp;utm_medium=toutiao.io&amp;utm_source=toutiao.io</a></p>