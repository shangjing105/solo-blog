title: 开发工具intellij idea solarized代码配色
date: '2016-05-12 11:12:10'
updated: '2016-05-12 11:12:10'
tags: [开发工具]
permalink: /articles/2016/05/11/1463022729894.html
---
<p>
	<span>github地址：<a href="https://github.com/jkaving/intellij-colors-solarized"><span>https://github.com/jkaving/intellij-colors-solarized</span></a></span>
</p>
<p>
	<span></span>
</p>
<p>
	<span></span>
</p>
<p>
	<span>效果图</span>
</p>
<p>
	<span><img src="http://o6n64wdk9.bkt.clouddn.com/7ee21d5496cd454e8ef46ff170c2d9c3.png" width="1060" height="640" alt="" /><br />
</span>
</p>