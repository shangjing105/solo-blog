title: spring boot与activemq的结合使用
date: '2016-12-12 16:56:43'
updated: '2016-12-12 16:57:57'
tags: [java, spring, spring boot, activemq]
permalink: /articles/2016/12/12/1481533003371.html
---

这几天试了试spring-jms结合activemq使用方法，项目架构使用的是spring boot。这里记下来，留着以后或许会使用。

使用的是spring-jms 4.2.3.RELEASE和activemq-client 5.14.1版本

## 1.关于jms和activemq

对jms和activemq不了解的可以先了解一下相关内容，这里提供一下地址：

[<<深入浅出JMS(一)--JMS基本概念>>](http://blog.csdn.net/jiuqiyuliang/article/details/46701559)

[<<深入浅出JMS(二)--ActiveMQ简单介绍以及安装>>](http://blog.csdn.net/jiuqiyuliang/article/details/47160259)


## 2.pom增加jar包

有了上面的了解，我们就可以开始下面的使用

```java
		<dependency>
            <groupId>org.apache.activemq</groupId>
            <artifactId>activemq-client</artifactId>
            <version>5.14.1</version>
        </dependency>
        <dependency>
            <groupId>org.springframework</groupId>
            <artifactId>spring-jms</artifactId>
        </dependency>
```        

## 3.spring boot配置

在这一步开始前，你需要在你的本地或远程安装好activemq的客户端，没有安装的百度或看下这篇文章
[<<深入浅出JMS(二)--ActiveMQ简单介绍以及安装>>](http://blog.csdn.net/jiuqiyuliang/article/details/47160259)

```
#jms activemq
spring.activemq.broker-url=tcp://localhost:61616
spring.activemq.user=admin
spring.activemq.password=admin
spring.activemq.in-memory=true
spring.activemq.pooled=false
```
上面配置了activemq的地址和用户名和密码

### 生产者

下面开始创建消息的生产者一方，这里我自定义了消息的实体对象、消息来源、消息转换器

生产者

```java
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import javax.jms.Destination;

/**
 * info:
 * Created by shang on 2016/12/2.
 */
@Component
public class Producer {
    @Autowired
    private JmsTemplate jmsTemplate;

    public void send(SprayEvent event,Destination destination,SprayMessageConverter messageConverter) {
        jmsTemplate.setMessageConverter(messageConverter);
        jmsTemplate.setDefaultDestination(destination);
        jmsTemplate.convertAndSend(event);
    }


}
```

消息实体，这里使用的是队列模式(Queue)

```java
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.stereotype.Component;

/**
 * info:jms activemq的事件
 * Created by shang on 2016/12/3.
 */
@Component
public class SprayEvent {

    /**
     * 消息类型:队列模式
     */
    public static final ActiveMQQueue SPRAY_TASK_EVENT_QUEUE=new ActiveMQQueue("SPRAY_TASK_EVENT_QUEUE");

    private Event event;

    private String text;

    public Event getEvent() {
        return event;
    }

    public void setEvent(Event event) {
        this.event = event;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public static enum Event {
        EVENT_TACK_SUCCESS; //定时任务执行成功
    }
}
```

消息转换器

```java
import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;
import javax.jms.TextMessage;

/**
 * info:
 * Created by shang on 2016/12/3.
 */
@Component
public class SprayMessageConverter implements MessageConverter{
    @Override
    public Message toMessage(Object o, Session session) throws JMSException, MessageConversionException {
        Assert.notNull(o);
        TextMessage message = session.createTextMessage();
        if(o instanceof SprayEvent){
            SprayEvent event = (SprayEvent) o;
            message.setStringProperty("event", event.getEvent().toString());
            message.setText(event.getText());
        }
        return message;
    }

    @Override
    public Object fromMessage(Message message) throws JMSException, MessageConversionException {
        return message;
    }
}
```

### 消费者

消费者比较简单，只要使用```@jmsListener``` 注解的方法即可监听指定事件
destination是生产者所发送的标识，用法如下：

```java
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/**
 * info:
 * Created by shang on 2016/12/2.
 */
@Component
public class Consumer {

    @JmsListener(destination = "SPRAY_TASK_EVENT_QUEUE")
    public void receiveMessage(String text) {
        System.out.println("消费了: <" + text + ">");
    }
}
```

---
***最后需要在spring boot启动里加上```@EnableJms``` 注解就可以***

##4.使用

在任意的方法里使用生产者的生产消息方法即可，如下方法：

```java
   @Autowired
    private Producer producer;

    @Scheduled(cron = "0/20 * * * * ? ")
    public void sendJms() {
        System.out.println("每20秒执行一次--------------------");
        SprayEvent event=new SprayEvent();
        event.setEvent(SprayEvent.Event.EVENT_TACK_SUCCESS);
        event.setText("Jms Message to activemq,my name is hello");
        producer.send(event,SprayEvent.SPRAY_TASK_EVENT_QUEUE,new SprayMessageConverter());

    }
```


## 5.结束

上面的内容就是spring boot 里使用activemq的方法，如果是spring mvc项目就可能需要配置spring-xml文件
网上也有不少相关案例，感觉这两篇文章不错

[<< 深入浅出JMS(三)--ActiveMQ简单的HelloWorld实例>>](http://blog.csdn.net/jiuqiyuliang/article/details/48608237)

[<<深入浅出JMS(四)--Spring和ActiveMQ整合的完整实例>>](http://blog.csdn.net/jiuqiyuliang/article/details/48758203)

有什么问题欢迎给我来信或留言！
