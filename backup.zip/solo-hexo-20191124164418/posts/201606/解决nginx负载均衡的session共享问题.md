title: 解决nginx负载均衡的session共享问题
date: '2016-06-26 19:13:14'
updated: '2016-06-26 19:13:14'
tags: [java, nginx]
permalink: /articles/2016/06/26/1466939534968.html
---
<div style="margin:0px;padding:0px;background-color:#FFFFFF;color:#333333;font-family:Exo, -apple-system, 'Open Sans', HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', 'Hiragino Sans GB', 'Microsoft YaHei', Helvetica, Arial, sans-serif;font-size:14px;">
	<div style="margin:0px;padding:0px;border:0px;">
		<span style="color:#362E2B;font-family:Arial;">用nginx做负载均衡，这样同一个IP访问同一个页面会被分配到不同的服务器上，如果session不同步的话，就会出现很多问题，比如说最常见的登录状态，下面提供了几种方式来解决session共享的问题：</span>
	</div>
</div>
<div style="margin:23px auto 15px;padding:23.03125px 15px 0px;border:0px;color:#333333;font-family:Exo, -apple-system, 'Open Sans', HelveticaNeue-Light, 'Helvetica Neue Light', 'Helvetica Neue', 'Hiragino Sans GB', 'Microsoft YaHei', Helvetica, Arial, sans-serif;font-size:14px;background-color:#EEEEEE;">
	<div style="margin:0px -15px;padding:0px;border:0px;">
		<div style="margin:0px;padding:0px 15px;border:0px;background-color:white;">
			<div style="margin:0px;padding:0px;border:0px;">
				<p style="color:#362E2B;font-family:Arial;">
					1、不使用session，换用cookie
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					session是存放在服务器端的，cookie是存放在客户端的，我们可以把用户访问页面产生的session放到cookie里面，就是以cookie为中转站。你访问web服务器A，产生了session然后把它放到cookie里面，当你的请求被分配到B服务器时，服务器B先判断服务器有没有这个session，如果没有，再去看看客户端的cookie里面有没有这个session，如果也没有，说明session真的不存，如果cookie里面有，就把cookie里面的sessoin同步到服务器B，这样就可以实现session的同步了。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					说明：这种方法实现起来简单，方便，也不会加大数据库的负担，但是如果客户端把cookie禁掉了的话，那么session就无从同步了，这样会给网站带来损失；cookie的安全性不高，虽然它已经加了密，但是还是可以伪造的。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					2、session存在数据库（MySQL等）中
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					PHP可以配置将session保存在数据库中，这种方法是把存放session的表和其他数据库表放在一起，如果mysql也做了集群了话，每个mysql节点都要有这张表，并且这张session表的数据表要实时同步。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					说明：用数据库来同步session，会加大数据库的IO，增加数据库的负担。而且数据库读写速度较慢，不利于session的适时同步。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					3、session存在memcache或者redis中
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					memcache可以做分布式，php配置文件中设置存储方式为memcache，这样php自己会建立一个session集群，将session数据存储在memcache中。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					说明：以这种方式来同步session，不会加大数据库的负担，并且安全性比用cookie大大的提高，把session放到内存里面，比从文件中读取要快很多。但是memcache把内存分成很多种规格的存储块，有块就有大小，这种方式也就决定了，memcache不能完全利用内存，会产生内存碎片，如果存储块不足，还会产生内存溢出。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					4、nginx中的ip_hash技术能够将某个ip的请求定向到同一台后端，这样一来这个ip下的某个客户端和某个后端就能建立起稳固的session，ip_hash是在upstream配置中定义的：
				</p>
				<ol style="color:#5C5C5C;margin-left:45px !important;">
					<li>
						<p>
							<span style="color:black;background-color:inherit;">upstream&nbsp;nginx.example.com&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;server&nbsp;192.168.74.235:80;&nbsp;&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;server&nbsp;192.168.74.236:80;&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ip_hash;&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;server&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;listen&nbsp;80;&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;location&nbsp;/&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;proxy_pass&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;http://nginx.example.com;&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}&nbsp;&nbsp;</span>
						</p>
					</li>
					<li>
						<p>
							<span style="color:black;background-color:inherit;">&nbsp;}&nbsp;&nbsp;</span>
						</p>
					</li>
				</ol>
				<p>
					<br />
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					<br />
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					ip_hash是容易理解的，但是因为仅仅能用ip这个因子来分配后端，因此ip_hash是有缺陷的，不能在一些情况下使用：<br />
1.nginx不是最前端的服务器。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					ip_hash要求nginx一定是最前端的服务器，否则nginx得不到正确ip，就不能根据ip作hash。譬如使用的是squid为最前端，那么nginx取ip时只能得到squid的服务器ip地址，用这个地址来作分流是肯定错乱的。<br />
2.nginx的后端还有其它方式的负载均衡。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					假如nginx后端又有其它负载均衡，将请求又通过另外的方式分流了，那么某个客户端的请求肯定不能定位到同一台session应用服务器上。这么算起来，nginx后端只能直接指向应用服务器，或者再搭一个squid，然后指向应用服务器。最好的办法是用 location作一次分流，将需要session的部分请求通过ip_hash分流，剩下的走其它后端去。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					5、upstream_hash<br />
为了解决ip_hash的一些问题，可以使用upstream_hash这个第三方模块，这个模块多数情况下是用作url_hash的，但是并不妨碍将它用来做session共享。没试过真心的不明白
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					补充：memcached简单的介绍
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					一、概念
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					Memcached是danga.com（运营LiveJournal的技术团队）开发的一套分布式内存对象缓存系统，用于在动态系统中减少数据库负载，提升性能。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					二、适用场合
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					1.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 分布式应用。由于memcached本身基于分布式的系统，所以尤其适合大型的分布式系统。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 数据库前段缓存。数据库常常是网站系统的瓶颈。数据库的大并发量访问，常常造成网站内存溢出。当然我们也可以使用Hibernate的缓存机制。但memcached是基于分布式的，并可独立于网站应用本身，所以更适合大型网站进行应用的拆分。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 服务器间数据共享。举例来讲，我们将网站的登录系统、查询系统拆分为两个应用，放在不同的服务器上，并进行集群，那这个时候用户登录后，登录信息如何从登录系统服务器同步到查询系统服务器呢？这时候，我们便可以使用memcached，登录系统将登录信息缓存起来，查询系统便可以获得登录信息，就像获取本地信息一样。
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					三、不适用场合
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					那些不需要“分布”的，不需要共享的，或者干脆规模小到只有一台服务器的应用，memcached不会带来任何好处，相反还会拖慢系统效率，因为网络连接同样需要资源
				</p>
				<p style="color:#362E2B;font-family:Arial;">
					&nbsp;
				</p>
			</div>
		</div>
	</div>
</div>