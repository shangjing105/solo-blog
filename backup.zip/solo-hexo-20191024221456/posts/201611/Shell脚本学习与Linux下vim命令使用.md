title: Shell脚本学习与Linux下vim命令使用
date: '2016-11-30 16:52:18'
updated: '2016-11-30 16:52:18'
tags: [shell, vim, Linux]
permalink: /articles/2016/11/30/1480495938107.html
---
## Shell介绍

> Shell 是一个用C语言编写的程序，它是用户使用Linux的桥梁。Shell既是一种命令语言，又是一种程序设计语言。
Shell 是指一种应用程序，这个应用程序提供了一个界面，用户通过这个界面访问操作系统内核的服务。
Ken Thompson的sh是第一种Unix Shell，Windows Explorer是一个典型的图形界面Shell。

我这里学习的主要是Bash的shell学习，需要的可以关注了解下。

## Shell的学习

最简单的shell脚本如下：

```
#!/bin/bash
echo "Hello World !"
```

"#!" 是一个约定的标记，它告诉系统这个脚本需要什么解释器来执行，即使用哪一种Shell

运行shell脚本，在Linux或mac下直接将上面内容保存为test.sh，然后直接：

```
./test.sh 
```

shell的变量，数组，运算学习，大家可以到下面地址学习：

《[菜鸟教程-Shell 教程](http://www.runoob.com/linux/linux-shell.html)》

## Shell的使用

这里放上第一个shell脚本

```
#!/bin/bash
echo '连接中...'
sshpass -p op7b14UN23 ssh root@192.168.30.5
```
上面的脚本是用来登录linux 远程主机的脚本，可以节省你去记忆的时间。

第二个shell脚本

```
#!/bin/bash
echo '开始tomcat项目,重启中....'
sshpass -p s9feO7Y9dqqa ssh -p 28852 root@45.78.57.1 'cd /usr/java/apache-tomcat-8.0.32_1/bin 
./catalina.sh stop 
./catalina.sh start'
echo '重启完成....'
```
这个脚本主要是用来重启linux主机上的tomcat项目的脚本。

第三个shell脚本

```
#!/bin/bash
cd /Users/aaa/git/test
mvn clean install
echo '打包完成....'
sshpass -p op7232UN2D ssh root@192.168.30.5 'rm -rf /home/www/jetty/webapps/ROOT.war'
sshpass -p op7232UN2D scp /Users/aaa/git/test/target/test-lastest.war root@192.168.30.5:/home/www/jetty/webapps/ROOT.war
echo '上传完成....'
sshpass -p op7232UN2D ssh root@192.168.30.5 'cd /home/www/jetty
./bin/jetty.sh restart'
echo '执行完成....'
```
第一步：将项目用maven打包编译。
第二步：将linux主机上的war包删掉，然后将打包好的上传上去。
第三步：重启项目。

**以上就是一些linux脚本的使用，更多的使用还需要根据需要自定义，上面有什么不对的地方请各位指正，还是菜鸟正在学习中，望大神手下留情。**


## Linux下vim命令

> Vim是从 vi 发展出来的一个文本编辑器。代码补完、编译及错误跳转等方便编程的功能特别丰富，在程序员中被广泛使用，被称为编辑器之神。与emacs一起被称为：emacs是神的编辑器，vim是编辑器之神。

有兴趣的可以了解下两者的区别：《[编辑器之神与神的编辑器](http://www.66test.com/Content/2041973.html)》

vim 共分为三种模式，分别是一般模式、编辑模式与指令列命令模式。
![vim](http://www.runoob.com/wp-content/uploads/2014/07/vim_model.png)

### Linux常用命令
#### 1.必知命令
```
i 进入到编辑模式
:w 保存文档
:w! 不保存文档，强制退出
:q 退出
:wq 保存退出
```

#### 2.移动光标
```
[Ctrl]+[f]	屏幕『向下』移动一页，相当于 [Page Down]按键 (常用)
[Ctrl]+[b]	屏幕『向上』移动一页，相当于 [Page Up] 按键 (常用)
[Ctrl]+[d]	屏幕『向下』移动半页
[Ctrl]+[u]	屏幕『向上』移动半页
0 	或功能键[Home]，移动到这一行的最前面字符处 (常用)
$ 	或功能键[End]	，移动到这一行的最后面字符处(常用)
H	光标移动到这个屏幕的最上方那一行的第一个字符
M	光标移动到这个屏幕的中央那一行的第一个字符
L	光标移动到这个屏幕的最下方那一行的第一个字符
G	移动到这个档案的最后一行(常用)
nG	移动到这个档案的第 n 行。例如 20G 则会移动到这个档案的第 20 行
gg	移动到这个档案的第一行，相当于 1G 啊！ (常用)
```

#### 3.搜寻与取代
```
/word	向光标之下寻找一个名称为 word 的字符串。
?word	向光标之上寻找一个字符串名称为 word 的字符串。
n	这个n是英文按键。代表重复前一个搜寻的动作。下一个
N	这个N是英文按键。与 n 刚好相反，为『反向』进行前一个搜寻动作。
```

#### 4.复制，删除，粘贴
```
yy 复制
nyy 复制n行
dd 删除
ndd 删除n行
p 粘贴
```

放上一张vim学习图
![vim](http://www.runoob.com/wp-content/uploads/2015/10/vi-vim-cheat-sheet-sch.gif)


## 结束
以上就是一些Shell脚本学习与Linux下vim命令使用，是我在工作过程中的使用和学习，
没有使用过的可以去尝试一下，简单好用你值的一学。

有什么问题欢迎给我来信或留言！
